package com.app.gamersshieldvpn

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
