import 'dart:io';
import 'ad_config_model.dart';

class AdHelper {
  static AdConfig? _config;

  /// Call this once after fetching API
  static void setConfig(AdConfig config) {
    _config = config;
  }

  static bool get isAdEnabled => _config?.status == 1;

  static String get bannerAdUnitId {
    if (!isAdEnabled) return '';
    if (Platform.isAndroid || Platform.isIOS) {
      return _config?.bannerAdId ?? 'ca-app-pub-3940256099942544/6300978111';
    }
    throw UnsupportedError('Unsupported platform');
  }

  static String get interstitialAdUnitId {
    if (!isAdEnabled) return '';
    if (Platform.isAndroid || Platform.isIOS) {
      return _config?.interstitialAdId ?? 'ca-app-pub-3940256099942544/1033173712';
    }
    throw UnsupportedError('Unsupported platform');
  }

  static String get rewardedAdUnitId {
    if (!isAdEnabled) return '';
    if (Platform.isAndroid || Platform.isIOS) {
      return _config?.rewardedAdId ?? 'ca-app-pub-3940256099942544/5224354917';
    }
    throw UnsupportedError('Unsupported platform');
  }
}
