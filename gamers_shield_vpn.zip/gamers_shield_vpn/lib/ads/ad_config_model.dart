class AdConfig {
  final String bannerAdId;
  final String interstitialAdId;
  final String rewardedAdId;
  final int status; // 1 = enabled, 0 = disabled

  AdConfig({
    required this.bannerAdId,
    required this.interstitialAdId,
    required this.rewardedAdId,
    required this.status,
  });

  factory AdConfig.fromJson(Map<String, dynamic> json) {
    return AdConfig(
      bannerAdId: json['banner_ads_id'] ?? '',
      interstitialAdId: json['interstistial_ads_id'] ?? '',
      rewardedAdId: json['rewarded_app_id'] ?? '',
      status: json['status'] ?? 0,
    );
  }
}
