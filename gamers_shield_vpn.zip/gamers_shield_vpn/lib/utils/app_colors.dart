import 'package:flutter/material.dart';

class AppColors{
  static Color appBgColor = const Color(0xff292A4C);
  static Color appButtonColor = const Color(0xff494968);
  static Color appWhiteColor = const Color(0xffffffff);
  static const Color appTextFieldFillColor = Color(0xff1D2031);
}