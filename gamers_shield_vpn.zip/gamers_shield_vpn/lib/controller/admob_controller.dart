import 'dart:developer';
import 'package:get/get.dart';
import '../ads/ad_config_model.dart';
import '../ads/ads_service.dart';
import '../data/model/base_model/api_response.dart';
import '../data/repository/admob_repo.dart';

class AdmobController extends GetxController {
  final AdmobRepo admobRepo;

  AdmobController({required this.admobRepo});

  bool _isLoadingAdmob = false;
  bool get isLoadingAdmob => _isLoadingAdmob;

  dynamic admobData;

  getAdmobData() async {
    _isLoadingAdmob = true;
    update();

    ApiResponse apiResponse = await admobRepo.getAdmob();

    _isLoadingAdmob = false;
    update();

    if (apiResponse.response != null && apiResponse.response!.statusCode == 200) {
      final data = apiResponse.response!.data;
      if (data != null && data is Map<String, dynamic>) {
        try {
          admobData = AdConfig.fromJson(data);
          AdHelper.setConfig(admobData);
        } catch (e) {
          log('Error parsing AdConfig: $e');
        }
      }
    } else {
      log('Failed to fetch AdMob config: ${apiResponse.error}');
    }
  }


}