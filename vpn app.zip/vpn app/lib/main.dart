import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Импорт для MethodChannel
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gamers_shield_vpn/screen/splash/splash_screen.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:workmanager/workmanager.dart'; // Импорт Workmanager
import 'di_container.dart' as di;
import 'firebase_options.dart';
import 'package:gamers_shield_vpn/background/background_tasks.dart'; // Импорт файла с фоновыми задачами
import 'package:gamers_shield_vpn/background/background_task_constants.dart'; // Импорт констант
import 'package:flutter/foundation.dart'; // Импорт для kDebugMode
import 'package:flutter_downloader/flutter_downloader.dart'; // Import flutter_downloader

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Инициализация FlutterDownloader с простой конфигурацией
  try {
    await FlutterDownloader.initialize(
      debug: true,
    );
    
    // Регистрируем простой колбэк без параметров для избежания ошибок
    FlutterDownloader.registerCallback(downloadCallback);
    
    if (kDebugMode) {
      print("FlutterDownloader успешно инициализирован");
    }
  } catch (e) {
    if (kDebugMode) {
      print("Ошибка при инициализации FlutterDownloader: $e");
    }
  }

  // Попытка инициализировать Firebase - убедимся что она выполняется в первую очередь
  try {
    if (kDebugMode) {
      print("Инициализация Firebase...");
    }
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    if (kDebugMode) {
      print("Firebase успешно инициализирован");
    }
  } catch (e) {
    if (kDebugMode) {
      print("Ошибка при инициализации Firebase: $e");
    }
    
    if (e.toString().contains('duplicate-app')) {
      // Игнорируем ошибку дублированной инициализации
      if (kDebugMode) {
        print('Firebase уже инициализирован');
      }
    } else {
      rethrow; // Пробрасываем другие ошибки
    }
  }

  // Инициализация зависимостей
  await di.init();

  runApp(const MyApp());
}

// Упрощенная версия callback-функции для FlutterDownloader
@pragma('vm:entry-point')
void downloadCallback(String id, int status, int progress) {
  if (kDebugMode) {
    print('Download task ($id) status: $status, progress: $progress%');
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(360, 810),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return GetMaterialApp(
          title: 'MRX',
          theme: ThemeData(
            useMaterial3: true,
            brightness: Brightness.dark,
            inputDecorationTheme: const InputDecorationTheme(
              border: OutlineInputBorder(),
            ),
          ),
          debugShowCheckedModeBanner: false,
          home: const SplashScreen(),
        );
      },
    );
  }
}