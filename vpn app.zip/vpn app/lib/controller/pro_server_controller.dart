// lib/controller/pro_server_controller.dart
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart'; // для использования debugPrint

class ProServerController extends GetxController {
  RxList<dynamic> serverData = <dynamic>[].obs;
  RxBool isLoading = false.obs; // Изменено на RxBool

  Future<void> fetchServers(String collectionName) async {
    isLoading.value = true; // Используем .value для RxBool
    update();
    try {
      QuerySnapshot<Map<String, dynamic>> querySnapshot =
      await FirebaseFirestore.instance.collection(collectionName).get();

      serverData.assignAll(querySnapshot.docs.map((doc) {
        var data = doc.data();
        data['id'] = doc.id;
        data['collection'] = collectionName;
        return data;
      }));
      debugPrint('Серверные данные успешно загружены из коллекции: $collectionName');
    } catch (error) {
      debugPrint('Ошибка при загрузке серверов: $error');
    } finally {
      isLoading.value = false; // Используем .value для RxBool
      update();
    }
  }

  @override
  void onInit() async {
    super.onInit();
    // Получаем название разрешенной коллекции и загружаем данные из нее
    String allowedCollection = await getAllowedCollection();
    fetchServers(allowedCollection);
  }

  // Метод для получения названия разрешенной коллекции с принудительной проверкой на сервере
  Future<String> getAllowedCollection() async {
    try {
      // Получаем идентификатор пользователя
      String userId = FirebaseAuth.instance.currentUser!.uid;
      debugPrint('Получен userId: $userId');

      //* Принудительно загружаем данные с сервера, чтобы избежать использования кэша
      DocumentSnapshot<Map<String, dynamic>> userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userId)
          .get(const GetOptions(source: Source.server));

      var data = userDoc.data();
      debugPrint('Данные пользователя: '); //

      // Проверяем и приводим typenumber к int, если он приходит как String
      int typeNumber;
      var typeNumberData = data?['typenumber'];
      if (typeNumberData is int) {
        typeNumber = typeNumberData;
      } else if (typeNumberData is String) {
        typeNumber = int.tryParse(typeNumberData) ?? -1;
        debugPrint('typenumber был String, преобразован в int: $typeNumber');
      } else {
        typeNumber = -1;
        debugPrint('typenumber имеет неизвестный формат');
      }

      // Определяем коллекцию в зависимости от значения typeNumber
      if (typeNumber == 0) {
        debugPrint('Возвращаем коллекцию: proservers');
        return 'proservers';
      } else if (typeNumber == 1) {
        debugPrint('Возвращаем коллекцию: proservers1');
        return 'proservers1';
      }
      else if (typeNumber == 2) {
        debugPrint('Возвращаем коллекцию: proservers2');
        return 'proservers2';
      }
      else if (typeNumber == 3) {
        debugPrint('Возвращаем коллекцию: proservers3');
        return 'proservers3';
      }
      else if (typeNumber == 4) {
        debugPrint('Возвращаем коллекцию: proservers4');
        return 'proservers4';
      }
      else if (typeNumber == 5) {
        debugPrint('Возвращаем коллекцию: proservers5');
        return 'proservers5';
      }
      else if (typeNumber == 6) {
        debugPrint('Возвращаем коллекцию: proservers6');
        return 'proservers6';
      }
      else if (typeNumber == 7) {
        debugPrint('Возвращаем коллекцию: proservers7');
        return 'proservers7';
      }
      else if (typeNumber == 8) {
        debugPrint('Возвращаем коллекцию: proservers8');
        return 'proservers0';
      }
      else {
        throw 'Неизвестное значение typenumber: $typeNumber';
      }
    } catch (e) {
      debugPrint('Ошибка при получении разрешенной коллекции: $e');
      return 'defaultCollection'; // Название коллекции по умолчанию
    }
  }
}