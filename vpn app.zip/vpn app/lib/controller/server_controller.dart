//server_controller.dart
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class ServerController extends GetxController {
  RxList<dynamic> serverData = <dynamic>[].obs;
  RxList<dynamic> proServerData = <dynamic>[].obs; // Добавляем для Pro серверов
  bool isLoading = false;
  bool isProLoading = false; // Добавляем для Pro загрузки

  Future<void> fetchFreeServers() async { // Переименовываем метод
    isLoading = true;
    update();
    try {
      QuerySnapshot<Map<String, dynamic>> querySnapshot =
      await FirebaseFirestore.instance.collection('servers').get();

      serverData.assignAll(querySnapshot.docs.map((doc) {
        var data = doc.data();
        data['id'] = doc.id;
        return data;
      }));
      isLoading = false;
      update();
    } catch (error) {
      isLoading = false;
      print('Error fetching free servers: $error');
    }
  }

  Future<void> fetchProServers(String collectionName) async { // Метод для загрузки Pro серверов
    isProLoading = true;
    update();
    try {
      QuerySnapshot<Map<String, dynamic>> querySnapshot =
      await FirebaseFirestore.instance.collection(collectionName).get();

      proServerData.assignAll(querySnapshot.docs.map((doc) {
        var data = doc.data();
        data['id'] = doc.id;
        data['collection'] = collectionName;
        return data;
      }));
      isProLoading = false;
      update();
    } catch (error) {
      isProLoading = false;
      print('Error fetching pro servers: $error');
    }
  }


  @override
  void onInit() async {
    super.onInit();
    fetchFreeServers(); // Загружаем бесплатные серверы при инициализации
  }
}