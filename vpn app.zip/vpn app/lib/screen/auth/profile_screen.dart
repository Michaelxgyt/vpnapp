import 'package:flutter/material.dart';
import 'package:gamers_shield_vpn/screen/auth/login_screen.dart'; 
import 'package:gamers_shield_vpn/screen/auth/register_screen.dart'; 
import 'package:gamers_shield_vpn/utils/app_constant.dart'; 
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:open_filex/open_filex.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'dart:io';
import 'dart:async';
import 'package:flutter_v2ray/flutter_v2ray.dart';
import 'package:lottie/lottie.dart';

// Класс для хранения статистики использования
class UsageStats {
  final double downloadedGB;
  final double uploadedGB;
  final int totalHours;
  final Map<String, double> weeklyActivity;

  UsageStats({
    required this.downloadedGB,
    required this.uploadedGB,
    required this.totalHours,
    required this.weeklyActivity,
  });
}

// Новый класс для редактирования профиля
class EditProfileScreen extends StatefulWidget {
  final Map<String, dynamic>? userProfile;

  const EditProfileScreen({Key? key, this.userProfile}) : super(key: key);

  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  late TextEditingController nameController;
  late TextEditingController emailController;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(
      text: widget.userProfile != null ? widget.userProfile!['name'] : '',
    );
    emailController = TextEditingController(
      text: widget.userProfile != null ? widget.userProfile!['email'] : '',
    );
  }

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    super.dispose();
  }

  Future<void> _updateProfile() async {
    if (nameController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Имя не может быть пустым')),
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? userId = prefs.getString("token");

      if (userId != null) {
        await FirebaseFirestore.instance.collection('users').doc(userId).update({
          'name': nameController.text,
          // Обновление email может потребовать дополнительной аутентификации
          // 'email': emailController.text,
        });
        // Optionally refresh the cached profile data after successful update
        // (A simple Get.back with result is sufficient if the parent screen refetches or receives the updated data)
        Get.back(result: true); // Возврат с результатом обновления
      }
    } catch (e) {
      print("Ошибка при обновлении профиля: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ошибка при обновлении профиля: $e')),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: Text(
          'Редактировать профиль',
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 24,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Get.back(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : SingleChildScrollView( // Added SingleChildScrollView
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Stack(
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.blueAccent,
                      child: widget.userProfile != null && widget.userProfile!['photoURL'] != null
                          ? ClipRRect(
                        borderRadius: BorderRadius.circular(50),
                        child: Image.network(
                          widget.userProfile!['photoURL'],
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Icon(Icons.person, size: 50, color: Colors.white),
                        ),
                      )
                          : Icon(Icons.person, size: 50, color: Colors.white),
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.blueAccent,
                          shape: BoxShape.circle,
                        ),
                        child: IconButton(
                          icon: Icon(Icons.camera_alt, color: Colors.white, size: 20),
                          onPressed: () {
                            // Здесь будет логика загрузки фото
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Функция находится в разработке')),
                            );
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 32),
              TextField(
                controller: nameController,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: 'Имя',
                  labelStyle: TextStyle(color: Colors.white70),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey[600]!),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.blueAccent),
                  ),
                  prefixIcon: Icon(Icons.person, color: Colors.white70),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: emailController,
                style: TextStyle(color: Colors.white),
                enabled: false, // Email обычно не меняется без верификации
                decoration: InputDecoration(
                  labelText: 'Email',
                  labelStyle: TextStyle(color: Colors.white70),
                  disabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: Colors.grey[600]!),
                  ),
                  prefixIcon: Icon(Icons.email, color: Colors.white70),
                ),
              ),
              SizedBox(height: 32),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  textStyle: GoogleFonts.roboto(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                onPressed: _updateProfile,
                child: Text('Сохранить изменения'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Экран для приобретения подписки
class SubscriptionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: Text(
          'Подписка',
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 24,
          ),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Выберите план подписки',
              style: GoogleFonts.outfit(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 32),
            _buildSubscriptionCard(
              title: 'Базовый',
              price: '0 руб.',
              period: 'бесплатно',
              features: [
                'Доступ к базовым серверам',
                'Ограниченная скорость',
                'Поддержка через форум',
              ],
              buttonText: 'Текущий план',
              isCurrentPlan: true,
              onPressed: () {}, // Disabled button for current plan
              backgroundColor: Colors.grey[800]!,
              borderColor: Colors.transparent,
            ),
            SizedBox(height: 16),
            _buildSubscriptionCard(
              title: 'PRO',
              price: '299 руб.',
              period: 'в месяц',
              features: [
                'Доступ ко всем серверам',
                'Максимальная скорость',
                'Приоритетная поддержка',
                'Без рекламы',
              ],
              buttonText: 'Выбрать',
              isPro: true,
              onPressed: () {
                // Логика оплаты
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Переход к оплате...')),
                );
              },
              backgroundColor: Colors.blueAccent.withOpacity(0.15),
              borderColor: Colors.blueAccent,
            ),
            SizedBox(height: 32),
            Text(
              'Все платежи проходят через защищенное соединение. Подписка продлевается автоматически, но вы можете отменить её в любое время.',
              style: GoogleFonts.roboto(
                fontSize: 12,
                color: Colors.white70,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubscriptionCard({
    required String title,
    required String price,
    required String period,
    required List<String> features,
    required String buttonText,
    required VoidCallback onPressed,
    bool isPro = false,
    bool isCurrentPlan = false,
    required Color backgroundColor,
    required Color borderColor,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 2),
        boxShadow: [
          BoxShadow(
            color: isPro ? Colors.blueAccent.withOpacity(0.3) : Colors.transparent,
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (isPro) ...[
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.blueAccent,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'РЕКОМЕНДУЕМ',
                  style: GoogleFonts.roboto(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
              SizedBox(height: 16),
            ],
            Text(
              title,
              style: GoogleFonts.outfit(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: isPro ? Colors.blueAccent : Colors.white,
              ),
            ),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  price,
                  style: GoogleFonts.outfit(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(width: 4),
                Text(
                  period,
                  style: GoogleFonts.roboto(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ),
              ],
            ),
            SizedBox(height: 24),
            ...features.map((feature) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Icon(Icons.check_circle, color: isPro ? Colors.blueAccent : Colors.green, size: 20),
                  SizedBox(width: 12),
                  Expanded( // Added Expanded to prevent overflow if feature text is long
                    child: Text(
                      feature,
                      style: GoogleFonts.roboto(
                        fontSize: 14,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            )),
            SizedBox(height: 24),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: isCurrentPlan ? Colors.grey[600] : Colors.blueAccent,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                minimumSize: Size(double.infinity, 48),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              onPressed: isCurrentPlan ? null : onPressed,
              child: Text(
                buttonText,
                style: GoogleFonts.roboto(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Основной класс экрана профиля
class MyProfileScreen extends StatefulWidget {
  const MyProfileScreen({super.key});

  @override
  _MyProfileScreenState createState() => _MyProfileScreenState();
}

class _MyProfileScreenState extends State<MyProfileScreen> with SingleTickerProviderStateMixin {
  Map<String, dynamic>? cachedUserProfile;
  bool isLoading = true;
  String? expiryDate;
  bool isDownloading = false;
  double downloadProgress = 0.0;
  bool isLoggedIn = true;
  String appVersion = ""; // Версия будет определяться автоматически

  // Переменные для загрузки
  double downloadSpeed = 0.0; // KB/s
  double downloaded = 0.0; // MB
  double totalSize = 0.0; // MB
  bool isCancelRequested = false;
  CancelToken? cancelToken;
  Stopwatch? downloadStopwatch;
  String estimatedTimeRemaining = "";

  // Переменные для вкладок
  late TabController _tabController;

  // Переменные для статистики использования
  UsageStats? usageStats;
  bool isLoadingStats = false;
  String? userId;

  // Переменные для обратного отсчета
  Timer? _timer;
  String remainingTimeFormatted = "";

  // Ensure FlutterV2ray is initialized correctly elsewhere in your app,
  // maybe in main or a separate service/controller.
  // For this example, we'll keep it here but note its lifecycle dependency
  // on this widget's state.
  final FlutterV2ray flutterV2ray = FlutterV2ray(onStatusChanged: (status) {
    print("VPN Status changed: ${status.state}");
    // Handle status changes if needed, e.g., update UI
  });


  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this); // 3 вкладки
    _tabController.addListener(_handleTabSelection);
    _getUserProfile();
    _getExpiryDate(); // This also gets userId
    _loadAppVersion(); // Получить версию приложения
  }

  Future<void> _loadAppVersion() async {
    try {
      final info = await PackageInfo.fromPlatform();
      if (mounted) {
        setState(() {
          appVersion = info.version;
        });
      }
    } catch (e) {
      // Если не удалось получить версию, оставить пусто или задать "неизвестно"
      if (mounted) {
        setState(() {
          appVersion = "неизвестно";
        });
      }
    }
  }

  void _handleTabSelection() {
    // Загружаем статистику только когда пользователь переходит на вкладку статистики
    // Ensure userId is available before attempting to load stats
    if (_tabController.index == 1 && usageStats == null && !isLoadingStats && userId != null) {
      _loadUsageStats();
    }
  }

  void _startCountdownTimer() {
    if (expiryDate == null) {
      if(mounted) {
        setState(() {
          remainingTimeFormatted = "Нет данных о подписке";
        });
      }
      return;
    }

    try {
      final expiry = DateTime.parse(expiryDate!);
      _timer?.cancel(); // Cancel previous timer if exists

      _timer = Timer.periodic(Duration(seconds: 1), (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        final now = DateTime.now();

        if (now.isAfter(expiry)) {
          setState(() {
            remainingTimeFormatted = "Срок подписки истек";
          });
          timer.cancel();
          return;
        }

        final difference = expiry.difference(now);
        final days = difference.inDays;
        final hours = difference.inHours % 24;
        final minutes = difference.inMinutes % 60;
        final seconds = difference.inSeconds % 60;

        setState(() {
          remainingTimeFormatted = "$days д $hours ч $minutes м $seconds с";
        });
      });
    } catch (e) {
      print("Ошибка при запуске таймера: $e");
      if(mounted) {
        setState(() {
          remainingTimeFormatted = "Ошибка таймера";
        });
      }
    }
  }

  @override
  void dispose() {
    _tabController.removeListener(_handleTabSelection);
    _tabController.dispose();
    _timer?.cancel();
    // Ensure cancel token is cancelled on dispose if download is active
    cancelToken?.cancel("Widget disposed");
    super.dispose();
  }

  Future<void> _getUserProfile() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userIdFromPrefs = prefs.getString("token");
    userId = userIdFromPrefs; // Set userId here

    if (userIdFromPrefs != null) {
      await fetchUserProfile(userIdFromPrefs);
      if(mounted) {
        setState(() {
          isLoggedIn = true;
        });
      }
    } else {
      if(mounted) {
        setState(() {
          isLoading = false;
          isLoggedIn = false;
        });
      }
    }
  }

  Future<void> fetchUserProfile(String id) async {
    if(mounted) {
      setState(() {
        isLoading = true;
      });
    }
    try {
      // Assuming 'token' in SharedPreferences is the document ID
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(id)
          .get();

      if (userDoc.exists) {
        cachedUserProfile = userDoc.data() as Map<String, dynamic>?;
        if (cachedUserProfile != null && cachedUserProfile!.containsKey('expiryDate') && cachedUserProfile!['expiryDate'] is Timestamp) {
          expiryDate = (cachedUserProfile!['expiryDate'] as Timestamp).toDate().toIso8601String();
          SharedPreferences prefs = await SharedPreferences.getInstance();
          await prefs.setString("expiryDate", expiryDate!);
          _startCountdownTimer(); // Start timer once expiry date is fetched
        } else {
          // Handle case where expiryDate is missing or not a Timestamp
          expiryDate = null;
          _timer?.cancel();
          if(mounted) {
            setState(() {
              remainingTimeFormatted = "Нет данных о подписке";
            });
          }
        }
      } else {
        cachedUserProfile = null; // User document not found
      }
    } catch (e) {
      print("Ошибка при получении профиля пользователя: $e");
      cachedUserProfile = null; // Clear profile on error
      expiryDate = null; // Clear expiry on error
      _timer?.cancel();
      if(mounted) {
        setState(() {
          remainingTimeFormatted = "Ошибка при получении данных";
        });
      }
    } finally {
      if(mounted) {
        setState(() {
          isLoading = false;
        });
      }
    }
  }


  Future<void> _getExpiryDate() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? expiryDateString = prefs.getString("expiryDate");
    String? userIdFromPrefs = prefs.getString("token");
    userId = userIdFromPrefs; // Ensure userId is set

    if (expiryDateString != null && expiryDateString.isNotEmpty) {
      if(mounted) {
        setState(() {
          expiryDate = expiryDateString;
        });
      }
      _startCountdownTimer();
    } else if (userId != null) {
      // If expiry date not in prefs, try fetching from Firestore
      try {
        DocumentSnapshot userDoc = await FirebaseFirestore.instance
            .collection('users')
            .doc(userId!)
            .get();
        if (userDoc.exists) {
          Map<String, dynamic>? userData = userDoc.data() as Map<String, dynamic>?;
          if (userData != null && userData.containsKey('expiryDate') && userData['expiryDate'] is Timestamp) {
            expiryDate = (userData['expiryDate'] as Timestamp).toDate().toIso8601String();
            await prefs.setString("expiryDate", expiryDate!);
            _startCountdownTimer();
          } else {
            // Handle missing or incorrect expiryDate type
            expiryDate = null;
            if(mounted) {
              setState(() {
                remainingTimeFormatted = "Нет данных о подписке";
              });
            }
          }
        } else {
          // User document not found, likely not logged in properly or profile missing
          expiryDate = null;
          if(mounted) {
            setState(() {
              remainingTimeFormatted = "Пользователь не найден";
            });
          }
        }
      } catch (e) {
        print("Ошибка при получении даты окончания подписки из Firestore: $e");
        expiryDate = null;
        if(mounted) {
          setState(() {
            remainingTimeFormatted = "Ошибка получения даты";
          });
        }
      }
    } else {
      // Not logged in, no expiry date
      expiryDate = null;
      if(mounted) {
        setState(() {
          remainingTimeFormatted = "Нет данных о подписке";
        });
      }
    }
  }


  // Загрузка статистики использования из Firebase
  Future<void> _loadUsageStats() async {
    if (userId == null) {
      print("userId is null, cannot load stats");
      return;
    }

    if(mounted) {
      setState(() {
        isLoadingStats = true;
      });
    }

    try {
      // Делаем один запрос для получения данных статистики
      DocumentSnapshot userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(userId!)
          .get();

      if (userDoc.exists) {
        Map<String, dynamic>? userData = userDoc.data() as Map<String, dynamic>?;
        if (userData != null && userData.containsKey('data')) {
          List<dynamic>? dataList = userData['data'] as List<dynamic>?;

          if (dataList != null && dataList.isNotEmpty) {
            // Парсинг и расчет общей статистики только за последние 30 дней
            usageStats = _calculateUsageStats(dataList.cast<String>());
          } else {
            usageStats = null; // No data found
          }
        } else {
          usageStats = null; // 'data' field missing
        }
      } else {
        usageStats = null; // User document not found
      }
    } catch (e) {
      print("Ошибка при получении статистики использования: $e");
      usageStats = null; // Clear stats on error
    } finally {
      if(mounted) {
        setState(() {
          isLoadingStats = false;
        });
      }
    }
  }

  // Расчет статистики из массива данных за последние 30 дней
  UsageStats _calculateUsageStats(List<String> dataList) {
    double totalDownloadGB = 0.0;
    double totalUploadGB = 0.0;
    
    // Новая карта для хранения данных за последние 7 дней вместо дней недели
    Map<String, double> weeklyActivity = {};
    
    // Получаем дату 30 дней назад и 7 дней назад
    final DateTime thirtyDaysAgo = DateTime.now().subtract(Duration(days: 30));
    final DateTime sevenDaysAgo = DateTime.now().subtract(Duration(days: 7));
    
    // Счетчик записей для подсчета времени (каждая запись = 20 минут)
    int recordCount = 0;

    // Создаем список для последних 7 дней с форматированными датами
    List<String> last7Days = [];
    for (int i = 6; i >= 0; i--) {
      DateTime date = DateTime.now().subtract(Duration(days: i));
      // Формат даты для отображения (день.месяц)
      String formattedDate = "${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}";
      last7Days.add(formattedDate);
      // Инициализируем карту с нулевыми значениями для всех 7 дней
      weeklyActivity[formattedDate] = 0.0;
    }

    // Обрабатываем данные
    for (String dataEntry in dataList) {
      try {
        List<String> parts = dataEntry.split('|');
        if (parts.length >= 3) {
          String dateTimeString = parts[0];
          DateTime entryDate = DateTime.parse(dateTimeString);
          
          // Проверяем, что запись не старше 30 дней (для общей статистики)
          if (entryDate.isAfter(thirtyDaysAgo)) {
            // Меняем местами индексы parts[1] и parts[2], как указано в коде
            double downloadGB = double.tryParse(parts[2]) ?? 0.0;
            double uploadGB = double.tryParse(parts[1]) ?? 0.0;
            
            // Добавляем данные к общей статистике за 30 дней
            totalDownloadGB += downloadGB;
            totalUploadGB += uploadGB;
            
            // Увеличиваем счетчик записей для расчета времени
            recordCount++;
            
            // Для графика активности используем только последние 7 дней
            if (entryDate.isAfter(sevenDaysAgo)) {
              // Формат даты для ключа в карте активности
              String dateKey = "${entryDate.day.toString().padLeft(2, '0')}.${entryDate.month.toString().padLeft(2, '0')}";
              
              // Если дата есть в нашем списке последних 7 дней, добавляем активность
              if (weeklyActivity.containsKey(dateKey)) {
                weeklyActivity[dateKey] = (weeklyActivity[dateKey] ?? 0.0) + (downloadGB + uploadGB);
              }
            }
          }
        }
      } catch (e) {
        print("Ошибка при парсинге записи данных: $e");
      }
    }

    // Рассчитываем общее время активности (20 минут на запись)
    // 20 минут = 1/3 часа, умножаем количество записей на 1/3
    int totalHours = (recordCount * 20 / 60).round();
    if (totalHours <= 0 && recordCount > 0) totalHours = 1; // Минимум 1 час если есть записи

    return UsageStats(
      downloadedGB: totalDownloadGB,
      uploadedGB: totalUploadGB,
      totalHours: totalHours,
      weeklyActivity: weeklyActivity,
    );
  }

  // Диаграмма активности за неделю с реальными данными
  Widget _buildWeeklyActivityChart() {
    // Check if usageStats is available and has data
    if (usageStats == null || usageStats!.weeklyActivity.isEmpty || usageStats!.weeklyActivity.values.every((value) => value == 0)) {
      return Center(child: Text('Нет данных за последнюю неделю', style: TextStyle(color: Colors.white70)));
    }

    // Find the maximum value for scaling the bars
    double maxValue = usageStats!.weeklyActivity.values.fold(0.1, (max, value) => value > max ? value : max);
    if (maxValue < 0.1) maxValue = 0.1; // Minimal value for normalization to avoid division by zero

    // Max height for the bar itself, leaving space for text above and below
    const double maxBarHeight = 130;

    return Container(
      height: 220, // Fixed height for the chart container
      padding: EdgeInsets.symmetric(vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.end, // Align columns to the bottom
        children: usageStats!.weeklyActivity.entries.map((entry) {
          double normalizedValue = entry.value / maxValue;
          double columnHeight = maxBarHeight * normalizedValue;
          // Ensure a minimum visible height for bars with small positive values
          if (columnHeight < 5 && entry.value > 0) {
            columnHeight = 5;
          } else if (entry.value == 0) {
            columnHeight = 0; // Bar height is 0 for 0 value
          }

          // Determine bar color based on value
          Color columnColor;
          if (normalizedValue > 0.7) {
            columnColor = Colors.greenAccent;
          } else if (normalizedValue > 0.3) {
            columnColor = Colors.blueAccent;
          } else {
            columnColor = Colors.blueGrey;
          }

          return Column(
            mainAxisAlignment: MainAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Value text above the bar
              Container(
                width: 40,
                child: Text(
                  entry.value > 0 ? '${entry.value.toStringAsFixed(1)}' : '',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                  ),
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              SizedBox(height: 4),
              // Bar representing the value
              Container(
                width: 30,
                height: columnHeight,
                decoration: BoxDecoration(
                  color: columnColor.withOpacity(0.8),
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(4),
                    bottom: Radius.circular(0),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: columnColor.withOpacity(0.2),
                      blurRadius: 4,
                      offset: Offset(0, 2),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 8),
              // Date label below the bar (changed from weekday)
              Text(
                entry.key,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w500,
                  fontSize: 12, // Уменьшен размер для лучшего отображения дат
                ),
              ),
            ],
          );
        }).toList(),
      ),
    );
  }

  // Расчет оставшегося времени подписки (для прогресс-бара)
  double _getRemainingTimePercent() {
    if (expiryDate == null) return 0.0;

    try {
      final now = DateTime.now();
      final expiry = DateTime.parse(expiryDate!);

      if (now.isAfter(expiry)) return 0.0; // Subscription expired

      // Assuming a typical subscription duration (e.g., 30 days) for percentage calculation
      // This is an estimation. A more accurate way would be to store the subscription start date.
      // If start date is not available, we can estimate based on expiry.
      // Let's assume PRO is monthly for simplicity in this calculation.
      // To make the percentage more meaningful, we need a start date or total duration.
      // If the expiry date is the *end* of a monthly subscription, a start date would be ~30 days prior.
      // Let's use a fixed 30-day window for calculation relative to the expiry date.
      const estimatedSubscriptionDurationDays = 30; // Assume monthly subscription

      // Calculate the start of the 30-day window ending at expiry
      final DateTime windowStart = expiry.subtract(Duration(days: estimatedSubscriptionDurationDays));

      // Calculate how much time has elapsed since the window start
      final elapsedInWindow = now.difference(windowStart);

      // Calculate the total duration of the window
      final totalWindowDuration = expiry.difference(windowStart);

      if (totalWindowDuration.inMilliseconds <= 0) return 0.0; // Avoid division by zero

      // Percentage of time remaining within the 30-day window
      double percentRemaining = 1.0 - (elapsedInWindow.inMilliseconds / totalWindowDuration.inMilliseconds);


      // Clamp the percentage between 0.0 and 1.0
      return percentRemaining.clamp(0.0, 1.0);

    } catch (e) {
      print("Ошибка при расчете процента времени подписки: $e");
      return 0.0;
    }
  }

  // Расчет оставшегося времени загрузки
  String _calculateRemainingTime() {
    if (downloadProgress <= 0 || downloadSpeed <= 0 || totalSize <= 0 || downloaded >= totalSize) {
      return "расчет...";
    }

    // downloaded and totalSize are in MB
    // downloadSpeed is in KB/s
    double remainingMB = totalSize - downloaded;
    double remainingKB = remainingMB * 1024;

    if (downloadSpeed <= 0) return "расчет...";

    double remainingSeconds = remainingKB / downloadSpeed;

    if (remainingSeconds.isNaN || remainingSeconds.isInfinite || remainingSeconds < 0) return "расчет...";


    if (remainingSeconds < 60) {
      return "${remainingSeconds.toInt()} сек";
    } else if (remainingSeconds < 3600) {
      int minutes = (remainingSeconds / 60).toInt();
      int seconds = (remainingSeconds % 60).toInt();
      return "${minutes} мин ${seconds} сек";
    } else {
      int hours = remainingSeconds ~/ 3600;
      int minutes = ((remainingSeconds % 3600) / 60).toInt();
      return "$hours ч ${minutes} мин";
    }
  }

  // Метод для построения элемента статистики
  Widget _buildStatItem(IconData icon, String title, String value, Color color) {
    return Expanded( // Use Expanded to make items take equal space
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[800],
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black12,
              blurRadius: 4,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            SizedBox(height: 12),
            Text(
              value,
              style: GoogleFonts.outfit(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
              textAlign: TextAlign.center, // Center text
            ),
            SizedBox(height: 4),
            Text(
              title,
              style: GoogleFonts.outfit(fontSize: 12, color: Colors.grey),
              textAlign: TextAlign.center, // Center text
            ),
          ],
        ),
      ),
    );
  }

  // Метод построения вкладки статистики
  Widget _buildStatisticsTab() {
    if (isLoadingStats) {
      return Center(child: CircularProgressIndicator());
    }

    // Check if usageStats is null or if its weekly activity values are all zero AND totalHours is zero
    if (usageStats == null || (usageStats!.weeklyActivity.isNotEmpty && usageStats!.weeklyActivity.values.every((value) => value == 0) && usageStats!.totalHours == 0)) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Icon(Icons.bar_chart, size: 80, color: Colors.grey[600]),
              SizedBox(height: 16),
              Text(
                usageStats == null
                    ? "Статистика еще не загружена или отсутствует"
                    : "Нет данных об использовании за последние 30 дней.",
                style: TextStyle(color: Colors.grey[400], fontSize: 18),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                onPressed: isLoadingStats || userId == null ? null : _loadUsageStats, 
                child: Text(userId == null ? "Нет пользователя" : "Загрузить данные"),
              ),
              if (userId == null) ...[
                SizedBox(height: 16),
                Text(
                  "Войдите в аккаунт, чтобы просмотреть статистику.",
                  style: TextStyle(color: Colors.grey[500], fontSize: 14),
                  textAlign: TextAlign.center,
                ),
              ],
            ],
          ),
        ),
      );
    }

    // If stats are available and not all zero, build the stats UI
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Статистика использования
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.trending_up, color: Colors.greenAccent),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        "Суммарная активность за 30 дней",
                        style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildStatItem(
                        Icons.timer,
                        "Время",
                        "${usageStats!.totalHours} ч",
                        Colors.blueAccent
                    ),
                    SizedBox(width: 12),
                    _buildStatItem(
                        Icons.cloud_download,
                        "Загружено",
                        "${usageStats!.downloadedGB.toStringAsFixed(1)} MB",
                        Colors.greenAccent
                    ),
                    SizedBox(width: 12),
                    _buildStatItem(
                        Icons.cloud_upload,
                        "Отправлено",
                        "${usageStats!.uploadedGB.toStringAsFixed(1)} MB",
                        Colors.orangeAccent
                    ),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 24),

          // График активности за неделю
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.show_chart, color: Colors.orangeAccent),
                    SizedBox(width: 8),
                    Text(
                      "Активность за неделю",
                      style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                  ],
                ),
                SizedBox(height: 8),
                Container(
                  height: 220,
                  child: _buildWeeklyActivityChart(),
                ),
                SizedBox(height: 8),
                Center(
                  child: Text(
                    "Объем данных по дням недели (MB)",
                    style: GoogleFonts.roboto(
                      fontSize: 12,
                      color: Colors.white70,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 24),

          // Кнопка обновления статистики
          ElevatedButton.icon(
            icon: Icon(Icons.refresh),
            label: Text("Обновить статистику"),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent,
              foregroundColor: Colors.white,
              padding: EdgeInsets.symmetric(vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: isLoadingStats || userId == null ? null : _loadUsageStats,
          ),
          SizedBox(height: 8),
          Center(
            child: Text(
              "Данные за последние 30 дней",
              style: GoogleFonts.roboto(
                fontSize: 12,
                color: Colors.white70,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> _checkInstallPermission() async {
    if (Platform.isAndroid) {
      // Check if the permission is already granted
      var status = await Permission.requestInstallPackages.status;
      if (status.isGranted) {
        return true;
      } else {
        // Request the permission
        var result = await Permission.requestInstallPackages.request();
        return result.isGranted;
      }
    }
    // Permission not applicable for other platforms or if checks fail
    return false; // Return false if not Android
  }

  Future<void> _downloadApk() async {
    if (!Platform.isAndroid) {
      if(mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Загрузка APK поддерживается только на Android.'),
            backgroundColor: Colors.orangeAccent,
          ),
        );
      }
      return;
    }

    const String url = 'https://github.com/Michaelxgyt/mrx.app/releases/download/v2rayng/mrx1.apk';
    try {
      bool hasInstallPermission = await _checkInstallPermission();
      if (!hasInstallPermission) {
        if(mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                  'Разрешение на установку приложений из неизвестных источников необходимо для установки обновления. Разрешите в настройках.'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
        // Option to open app settings for permission
        Future.delayed(Duration(seconds: 3), () {
          openAppSettings();
        });
        return;
      }

      if(mounted) {
        setState(() {
          isDownloading = true;
          downloadProgress = 0.0;
          downloadSpeed = 0.0;
          downloaded = 0.0;
          totalSize = 0.0;
          isCancelRequested = false;
          estimatedTimeRemaining = "";
        });
      }


      Directory? appDocDir = await getApplicationDocumentsDirectory();
      if (appDocDir == null) {
        throw Exception("Не удалось получить директорию для сохранения.");
      }
      String savePath = '${appDocDir.path}/mrx1.apk';

      Dio dio = Dio();
      cancelToken = CancelToken();
      downloadStopwatch = Stopwatch()..start();
      int lastReceived = 0;
      DateTime lastUpdateTime = DateTime.now();

      await dio.download(
        url,
        savePath,
        cancelToken: cancelToken,
        onReceiveProgress: (received, total) {
          if (total != -1 && mounted) {
            DateTime now = DateTime.now();
            int durationInMs = now.difference(lastUpdateTime).inMilliseconds;

            setState(() {
              downloadProgress = received / total;
              totalSize = total / (1024 * 1024); // Total size in MB
              downloaded = received / (1024 * 1024); // Downloaded in MB

              // Calculate speed only if time has elapsed
              if (durationInMs > 0) {
                double bytesReceivedSinceLastUpdate = received - lastReceived.toDouble();
                // Calculate speed in KB/s
                // (bytes / 1024) / (seconds)
                downloadSpeed = (bytesReceivedSinceLastUpdate / 1024.0) / (durationInMs / 1000.0); // KB per second
                lastReceived = received;
                lastUpdateTime = now;

                // Update estimated time
                estimatedTimeRemaining = _calculateRemainingTime();
              }
            });
          }
        },
      );

      downloadStopwatch!.stop();
      if(mounted) {
        setState(() {
          isDownloading = false;
          downloadProgress = 1.0; // Ensure progress is 100% on completion
          downloadSpeed = 0.0; // Reset speed
          cancelToken = null; // Clear cancel token
          downloadStopwatch = null; // Clear stopwatch
          estimatedTimeRemaining = "Завершено"; // Update remaining time status
        });
      }


      File apkFile = File(savePath);
      if (!await apkFile.exists()) {
        if(mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Файл обновления не найден после загрузки.'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
        return;
      } else {
        print("Путь к APK: $savePath");
      }

      // Show installation prompt
      bool? installConfirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          backgroundColor: Colors.grey[850],
          title: Text("Обновление загружено", style: TextStyle(color: Colors.white)),
          content: Text("Новая версия приложения готова к установке. Установить сейчас?", style: TextStyle(color: Colors.white70)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: Text("Позже", style: TextStyle(color: Colors.white70)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              ),
              onPressed: () => Navigator.of(context).pop(true),
              child: Text("Установить"),
            ),
          ],
        ),
      );

      if (installConfirm == true) {
        await _installApk(savePath);
      }

    } catch (e) {
      if (e is DioException && CancelToken.isCancel(e)) {
        print("Загрузка отменена: ${e.message}");
        if(mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Загрузка отменена.'),
              backgroundColor: Colors.orangeAccent,
            ),
          );
        }
      } else {
        print("Ошибка при загрузке APK: $e");
        if(mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Ошибка при загрузке: ${e.toString()}'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
      }
      if(mounted) {
        setState(() {
          isDownloading = false;
          downloadProgress = 0.0;
          downloadSpeed = 0.0;
          downloaded = 0.0;
          totalSize = 0.0;
          cancelToken = null;
          downloadStopwatch = null;
          isCancelRequested = false; // Reset cancel state
          estimatedTimeRemaining = "Ошибка"; // Update remaining time status
        });
      }
    }
  }

  void _cancelDownload() {
    if (cancelToken != null && !cancelToken!.isCancelled) {
      cancelToken!.cancel("Download cancelled by user.");
      // State will be updated in the catch block of _downloadApk after cancellation is processed
      if(mounted) {
        setState(() {
          isCancelRequested = true; // Indicate that cancellation is requested
        });
      }
    }
  }

  Future<void> _installApk(String filePath) async {
    try {
      final result = await OpenFilex.open(filePath);
      if (result.type != ResultType.done) {
        print("Ошибка открытия файла для установки: ${result.message}");
        if(mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text(
                    'Не удалось открыть файл для установки. Ошибка: ${result.message}'),
                backgroundColor: Colors.redAccent),
          );
        }
      } else {
        print("Файл открыт для установки.");
      }
    } catch (e) {
      print("Исключение при установке APK: $e");
      if(mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Произошла ошибка при попытке установить приложение: ${e.toString()}'),
              backgroundColor: Colors.redAccent),
        );
      }
    }
  }

  // Метод построения вкладки профиля
  Widget _buildProfileTab() {
    if (isLoading) {
      return Center(child: CircularProgressIndicator());
    }

    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Карточка профиля
          Container(
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black26,
                  blurRadius: 6,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.blueAccent,
                    // Check if photoURL exists, is not null, and is a valid URI before using Image.network
                    child: cachedUserProfile != null && cachedUserProfile!['photoURL'] != null && Uri.tryParse(cachedUserProfile!['photoURL'])?.hasAbsolutePath == true
                        ? ClipRRect(
                      borderRadius: BorderRadius.circular(40),
                      child: Image.network(
                        cachedUserProfile!['photoURL'],
                        width: 80,
                        height: 80,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) => Icon(Icons.person, size: 40, color: Colors.white), // Fallback icon on error
                      ),
                    )
                        : Icon(Icons.person, size: 40, color: Colors.white), // Default icon
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          cachedUserProfile != null
                              ? cachedUserProfile!['name'] ?? 'Имя отсутствует'
                              : 'Имя отсутствует',
                          style: GoogleFonts.outfit(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 4),
                        Text(
                          cachedUserProfile != null
                              ? cachedUserProfile!['email'] ?? 'Email отсутствует'
                              : 'Email отсутствует',
                          style: GoogleFonts.outfit(
                            fontSize: 14,
                            color: Colors.white70,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        SizedBox(height: 16),
                        ElevatedButton.icon(
                          icon: Icon(Icons.edit, size: 16),
                          label: Text("Редактировать"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey[700],
                            foregroundColor: Colors.white,
                            textStyle: GoogleFonts.outfit(fontSize: 14),
                            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          ),
                          onPressed: () async {
                            // Navigate and wait for result
                            final result = await Get.to(() => EditProfileScreen(userProfile: cachedUserProfile));
                            // Check result and refresh if update occurred
                            if (result == true) {
                              _getUserProfile(); // Refresh profile data after editing
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 24),

          // Карточка подписки
          Card(
            color: Colors.grey[850],
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Информация о подписке",
                    style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      Icon(
                        cachedUserProfile != null && cachedUserProfile!['type'] == 'Pro'
                            ? Icons.verified
                            : Icons.not_interested,
                        color: cachedUserProfile != null && cachedUserProfile!['type'] == 'Pro'
                            ? Colors.greenAccent
                            : Colors.orangeAccent,
                        size: 24,
                      ),
                      SizedBox(width: 10),
                      Text(
                        cachedUserProfile != null && cachedUserProfile!['type'] == 'Pro'
                            ? "Премиум аккаунт"
                            : "Базовый аккаунт",
                        style: GoogleFonts.outfit(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: cachedUserProfile != null && cachedUserProfile!['type'] == 'Pro'
                              ? Colors.greenAccent
                              : Colors.orangeAccent,
                        ),
                      ),
                      Spacer(),
                      if (cachedUserProfile != null && cachedUserProfile!['type'] != 'Pro')
                        TextButton(
                          onPressed: _showUpgradeDialog, // Call the defined method
                          child: Text(
                            "Обновить",
                            style: TextStyle(color: Colors.blueAccent),
                          ),
                        ),
                    ],
                  ),
                  if (cachedUserProfile != null && cachedUserProfile!['type'] == 'Pro' && expiryDate != null) ...[
                    SizedBox(height: 16),
                    Row(
                      children: [
                        Icon(Icons.access_time, color: Colors.white70, size: 18),
                        SizedBox(width: 10),
                        Text(
                          // Ensure expiryDate is not null before formatting
                          expiryDate != null ? 'Действует до: ${DateFormat('dd.MM.yyyy HH:mm').format(DateTime.parse(expiryDate!))}' : 'Дата истечения неизвестна',
                          style: GoogleFonts.outfit(fontSize: 14, color: Colors.white70),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: _getRemainingTimePercent(),
                        backgroundColor: Colors.grey[700],
                        valueColor: AlwaysStoppedAnimation<Color>(
                          _getRemainingTimePercent() > 0.25 ? Colors.greenAccent : Colors.orangeAccent,
                        ),
                        minHeight: 10,
                      ),
                    ),
                    SizedBox(height: 8),
                    // Show loading if date exists but formatted string is empty, otherwise show the formatted string
                    remainingTimeFormatted.isEmpty && expiryDate != null
                        ? SizedBox(height: 20, child: Center(child: LinearProgressIndicator(backgroundColor: Colors.grey[800])))
                        : Text(
                      'Осталось: ${remainingTimeFormatted.isEmpty ? "Загрузка..." : remainingTimeFormatted}', // Show "Загрузка..." if empty initially
                      style: GoogleFonts.outfit(
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: _getRemainingTimePercent() > 0.25 ? Colors.greenAccent : Colors.orangeAccent,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Метод построения вкладки настроек
  Widget _buildSettingsTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (isDownloading) ...[
            Container(
              margin: EdgeInsets.only(bottom: 24),
              padding: EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.grey[850],
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.blueAccent.withOpacity(0.5), width: 1),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.system_update, color: Colors.blueAccent),
                      SizedBox(width: 10),
                      Text(
                        "Обновление приложения",
                        style: GoogleFonts.outfit(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: downloadProgress,
                      backgroundColor: Colors.grey[700],
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent),
                      minHeight: 10,
                    ),
                  ),
                  SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Скачано: ${(downloadProgress * 100).toInt()}%',
                        style: GoogleFonts.roboto(color: Colors.white70, fontSize: 12),
                      ),
                      Text(
                        '${downloaded.toStringAsFixed(2)} MB / ${totalSize.toStringAsFixed(2)} MB',
                        style: GoogleFonts.roboto(color: Colors.white70, fontSize: 12),
                      ),
                    ],
                  ),
                  SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        // Ensure downloadSpeed is not negative or NaN/Infinite
                        'Скорость: ${downloadSpeed.isFinite && downloadSpeed >= 0 ? downloadSpeed.toStringAsFixed(2) : '0.00'} KB/s',
                        style: GoogleFonts.roboto(color: Colors.white70, fontSize: 12),
                      ),
                      Text(
                        'Осталось: $estimatedTimeRemaining',
                        style: GoogleFonts.roboto(color: Colors.white70, fontSize: 12),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  Center(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        foregroundColor: Colors.white,
                        textStyle: GoogleFonts.roboto(fontWeight: FontWeight.w500),
                        minimumSize: Size(120, 36),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                      ),
                      onPressed: _cancelDownload,
                      child: Text("Отменить"),
                    ),
                  ),
                ],
              ),
            ),
          ],
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Настройки приложения",
                  style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                SizedBox(height: 16),
                _buildSettingsItem(
                  icon: Icons.language,
                  title: "Язык приложения",
                  subtitle: "Русский",
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Функция находится в разработке')),
                    );
                  },
                ),
                _buildSettingsItem(
                  icon: Icons.notifications,
                  title: "Уведомления",
                  subtitle: "Включены",
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Функция находится в разработке')),
                    );
                  },
                ),
                _buildSettingsItem(
                  icon: Icons.privacy_tip,
                  title: "Политика конфиденциальности",
                  subtitle: "Информация об использовании данных",
                  onTap: () async {
                    final Uri url = Uri.parse('https://privacy-policy-url.example.com'); // Placeholder URL
                    try {
                      if (await canLaunchUrl(url)) {
                        await launchUrl(url, mode: LaunchMode.externalApplication);
                      } else {
                        if(mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Не удалось открыть политику конфиденциальности.')),
                          );
                        }
                      }
                    } catch (e) {
                      print("Error launching privacy policy URL: $e");
                      if(mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('Произошла ошибка при открытии ссылки.')),
                        );
                      }
                    }
                  },
                ),
                _buildSettingsItem(
                  icon: Icons.help_outline,
                  title: "Справка",
                  subtitle: "Часто задаваемые вопросы",
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Функция находится в разработке')),
                    );
                  },
                ),
                _buildSettingsItem(
                  icon: Icons.logout,
                  title: "Выйти из аккаунта",
                  subtitle: "Завершить текущую сессию",
                  onTap: () async {
                    bool? confirmLogout = await showDialog<bool>(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          backgroundColor: Colors.grey[850],
                          title: Text('Подтверждение выхода', style: TextStyle(color: Colors.white)),
                          content: Text(
                            'Вы уверены, что хотите выйти из аккаунта?',
                            style: TextStyle(color: Colors.white70),
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          actions: [
                            TextButton(
                              child: Text(
                                'Отмена',
                                style: TextStyle(color: Colors.white70),
                              ),
                              onPressed: () => Navigator.of(context).pop(false),
                            ),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.redAccent,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              child: Text('Выйти'),
                              onPressed: () async {
                                // Stop VPN before clearing data
                                try {
                                  await flutterV2ray.stopV2Ray();
                                  print('VPN соединение отключено');
                                } catch (e) {
                                  print("Ошибка при отключении VPN: $e");
                                  // Continue logout even if VPN stop fails
                                }

                                SharedPreferences prefs = await SharedPreferences.getInstance();
                                await prefs.clear(); // Clear all shared preferences

                                // Navigate to login and remove all previous routes
                                Navigator.of(context).pop(true); // Close dialog
                                Get.offAll(() => LoginScreen());
                              },
                            ),
                          ],
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          ),
          SizedBox(height: 24),
          Container(
            padding: EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "О приложении",
                  style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                SizedBox(height: 16),
                Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Colors.grey[800],
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.shield_outlined,
                        color: Colors.blueAccent,
                        size: 40,
                      ),
                    ),
                    SizedBox(width: 16),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "MRX VPN",
                          style: GoogleFonts.outfit(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          "Версия $appVersion", // Используем полученную версию
                          style: GoogleFonts.outfit(
                            fontSize: 14,
                            color: Colors.grey[400],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(height: 16),
                Text(
                  "© 2023-2025 MRX VPN. Все права защищены.",
                  style: GoogleFonts.roboto(
                    fontSize: 12,
                    color: Colors.grey[400],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: Colors.blueAccent),
      title: Text(
        title,
        style: GoogleFonts.outfit(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
      ),
      subtitle: Text(
        subtitle,
        style: GoogleFonts.outfit(fontSize: 14, color: Colors.white70),
      ),
      onTap: onTap,
    );
  }

  // Method to show the upgrade dialog when user clicks "Обновить"
  void _showUpgradeDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.grey[850],
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.blueAccent.withOpacity(0.3)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  alignment: Alignment.center,
                  children: [
                    Container(
                      width: double.infinity,
                      height: 100,
                      decoration: BoxDecoration(
                        color: Colors.blueAccent.withOpacity(0.15),
                        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                      ),
                    ),
                    Positioned(
                      top: 20,
                      child: Text(
                        "Премиум доступ",
                        style: GoogleFonts.outfit(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 60,
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.blueAccent,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Text(
                          "Разблокируйте все возможности",
                          style: GoogleFonts.outfit(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    children: [
                      _buildFeatureItem("Максимальная скорость соединения"),
                      _buildFeatureItem("Доступ к премиум серверам"),
                      _buildFeatureItem("Приоритетная поддержка 24/7"),
                      _buildFeatureItem("Без рекламы и ограничений"),
                      SizedBox(height: 24),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blueAccent,
                                foregroundColor: Colors.white,
                                padding: EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                              onPressed: () {
                                Navigator.pop(context);
                                // Navigate to subscription screen
                                Get.to(() => SubscriptionScreen());
                              },
                              child: Text(
                                "Продолжить",
                                style: GoogleFonts.roboto(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 16),
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: Text(
                          "Не сейчас",
                          style: TextStyle(color: Colors.white70),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Helper method to build feature items in the upgrade dialog
  Widget _buildFeatureItem(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(2),
            decoration: BoxDecoration(
              color: Colors.blueAccent.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.check,
              color: Colors.blueAccent,
              size: 16,
            ),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.outfit(
                fontSize: 14,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: Text(
          'Мой аккаунт',
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontWeight: FontWeight.w500,
            fontSize: 24,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.support_agent, color: Colors.white),
            onPressed: () async {
              const telegramUrl = 'tg://resolve?domain=ShadowsockTM'; // Updated Telegram handle if needed
              final Uri url = Uri.parse(telegramUrl);
              try {
                if (await canLaunchUrl(url)) {
                  await launchUrl(url, mode: LaunchMode.externalApplication);
                } else {
                  // Fallback to web link
                  final Uri webUrl = Uri.parse('https://t.me/ShadowsockTM'); // Updated Telegram handle if needed
                  if (await canLaunchUrl(webUrl)) {
                    await launchUrl(webUrl, mode: LaunchMode.externalApplication);
                  } else {
                    if(mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Не удалось открыть Telegram.'),
                          backgroundColor: Colors.redAccent,
                        ),
                      );
                    }
                  }
                }
              } catch (e) {
                print("Error launching Telegram: $e");
                if(mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Произошла ошибка при открытии Telegram.'),
                      backgroundColor: Colors.redAccent,
                    ),
                  );
                }
              }
            },
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : !isLoggedIn
          ? Padding(
        padding: const EdgeInsets.only(bottom: 60.0),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Lottie.asset(
                  'assets/lottie/sign.json', // Ensure this path exists
                  width: 200,
                  height: 200,
                  repeat: true,
                  reverse: false,
                  animate: true,
                  errorBuilder: (context, error, stackTrace) {
                    // Provide a fallback if Lottie asset fails
                    return Icon(Icons.person_off, size: 100, color: Colors.grey);
                  },
                ),
                SizedBox(height: 20),
                Text(
                  'Вы не вошли в аккаунт',
                  style: GoogleFonts.outfit(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 24),
                Text(
                  'Войдите или зарегистрируйтесь, чтобы получить доступ к полному функционалу.',
                  style: GoogleFonts.outfit(
                    fontSize: 16,
                    color: Colors.white70,
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 40),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 50, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    textStyle: GoogleFonts.roboto(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  onPressed: () {
                    // Use Get.off or Get.offAll if you don't want to navigate back
                    Get.off(() => LoginScreen());
                  },
                  child: Text('Войти'),
                ),
                SizedBox(height: 16),
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white70,
                    padding: EdgeInsets.symmetric(horizontal: 50, vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    side: BorderSide(color: Colors.white54),
                    textStyle: GoogleFonts.roboto(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  onPressed: () {
                    // Use Get.to for registration, allowing back navigation if needed
                    Get.to(() => RegisterScreen());
                  },
                  child: Text('Регистрация'),
                ),
              ],
            ),
          ),
        ),
      )
          : Column(
        children: [
          TabBar(
            controller: _tabController,
            labelColor: Colors.blueAccent,
            unselectedLabelColor: Colors.grey,
            indicatorColor: Colors.blueAccent,
            tabs: [
              Tab(text: "Профиль", icon: Icon(Icons.person)),
              Tab(text: "Статистика", icon: Icon(Icons.bar_chart)),
              Tab(text: "Настройки", icon: Icon(Icons.settings)),
            ],
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildProfileTab(),
                _buildStatisticsTab(),
                _buildSettingsTab(),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: isLoggedIn && isDownloading
          ? Padding(
        padding: const EdgeInsets.all(24.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
                foregroundColor: Colors.white,
                minimumSize: Size(200, 40),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                elevation: 0,
              ),
              onPressed: _cancelDownload,
              child: Text(
                "Отменить загрузку",
                style: GoogleFonts.roboto(
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
              ),
            ),
          ],
        ),
      )
          : null,
    );
  }
}
