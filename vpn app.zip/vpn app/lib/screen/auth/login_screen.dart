// login_screen.dart (Полный код - ИСПРАВЛЕННАЯ ВЕРСИЯ с type casting для containsKey)
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:gamers_shield_vpn/screen/auth/register_screen.dart';
import 'package:gamers_shield_vpn/screen/home/home_screen.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/services.dart';
import 'package:device_information/device_information.dart';
import 'package:permission_handler/permission_handler.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool isLoading = false;

  // Функция для получения IMEI с запросом разрешения (теперь вызывается каждый раз)
  Future<String?> _getImeiWithPermission() async {
    PermissionStatus status = await Permission.phone.status; // Получаем текущий статус разрешения

    if (status.isGranted) { // Если разрешение уже есть, пытаемся получить IMEI
      try {
        return await DeviceInformation.deviceIMEINumber;
      } on PlatformException catch (e) {
        print("Ошибка получения IMEI: ${e.message}");
        return null; // Возвращаем null в случае ошибки получения IMEI
      }
    } else { // Если разрешения нет (denied, permanentlyDenied, или restricted)
      // Запрашиваем разрешение каждый раз, когда вызывается функция
      status = await Permission.phone.request();
      if (status.isGranted) { // Проверяем, было ли разрешение предоставлено после запроса
        try {
          return await DeviceInformation.deviceIMEINumber;
        } on PlatformException catch (e) {
          print("Ошибка получения IMEI после запроса: ${e.message}");
          return null; // Возвращаем null в случае ошибки после запроса
        }
      } else { // Если разрешение так и не было получено
        print("Разрешение READ_PHONE_STATE не получено пользователем");
        return null; // Возвращаем null, если разрешение так и не получено
      }
    }
  }


  Future<void> loginUser() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isLoading = true;
      });

      String? imeiNo = await _getImeiWithPermission(); // Получаем IMEI с запросом разрешения (каждый раз)

      if (imeiNo == null) { // Проверяем, удалось ли получить IMEI (если не удалось, блокируем вход)
        setState(() {
          isLoading = false;
        });

        PermissionStatus status = await Permission.phone.status; // Получаем статус разрешения снова

        if (status.isPermanentlyDenied) { // Проверяем, если "permanentlyDenied"
          Get.snackbar(
            "Ошибка",
            "Для входа необходимо разрешение \"Телефон\". Пожалуйста, перейдите в Настройки приложения и включите разрешение вручную.",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.red,
            mainButton: TextButton(
              onPressed: () {
                openAppSettings(); // Открываем настройки приложения
              },
              child: const Text(
                'Открыть настройки',
                style: TextStyle(color: Colors.white),
              ),
            ),
          );
        } else { // Если не "permanentlyDenied", значит, другая ошибка или просто отказался
          Get.snackbar(
            "Ошибка",
            "Не удалось получить IMEI устройства. Вход невозможен. Пожалуйста, дайте разрешения на IMEI.",
            snackPosition: SnackPosition.BOTTOM,
            backgroundColor: Colors.red,
          );
        }
        return; // Выходим из функции, если IMEI не получен
      }


      try {
        UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: emailController.text.trim(),
          password: passwordController.text.trim(),
        );

        String uid = userCredential.user!.uid;

        final DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
        String deviceId;

        if (Theme.of(context).platform == TargetPlatform.iOS) {
          final IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
          deviceId = iosInfo.identifierForVendor!;
        } else {
          final AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
          deviceId = androidInfo.id;
        }

        DocumentSnapshot userDoc = await FirebaseFirestore.instance.collection('users').doc(uid).get();

        // Исправлено: Явное приведение типа для userDoc.data()
        final userData = userDoc.data() as Map<String, dynamic>?;

        // Проверяем, есть ли поле 'imei_no' в документе пользователя
        if (!userDoc.exists || userData == null || !userData.containsKey('imei_no')) {
          // Поле 'imei_no' отсутствует, добавляем его
          await FirebaseFirestore.instance.collection('users').doc(uid).update({'imei_no': imeiNo});
          print("Поле imei_no добавлено в Firestore для пользователя $uid");
        }

        String storedDeviceId = userDoc['device_id'] as String? ?? ''; // Безопасное получение device_id
        String storedImeiNo = userDoc['imei_no'] as String? ?? '';     // Безопасное получение imei_no


        if (deviceId != storedDeviceId || imeiNo != storedImeiNo) { // Проверка IMEI теперь обязательна
          setState(() {
            isLoading = false;
          });
          Get.snackbar("Ошибка", "Это устройство не авторизовано для доступа к этому аккаунту (IMEI не совпадает).",
              snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red);
          return;
        }

        SharedPreferences preferences = await SharedPreferences.getInstance();
        if (uid != null) {
          await preferences.setString("token", uid);
          await preferences.setString("email", emailController.text.trim());
        }

        Get.snackbar(
          "Успех",
          "Вы успешно вошли",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green,
        );

        Get.offAll(() => const HomeScreen());
      } on FirebaseAuthException catch (e) {
        String message;
        if (e.code == 'user-not-found') {
          message = 'Пользователь с таким email не найден.';
        } else if (e.code == 'wrong-password') {
          message = 'Неверный пароль.';
        } else {
          message = 'Произошла ошибка. Пожалуйста, попробуйте снова.';
        }
        Get.snackbar("Ошибка", message,
            snackPosition: SnackPosition.BOTTOM, backgroundColor: Colors.red);
      } finally {
        setState(() {
          isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: Text(
          'Вход',
          style: GoogleFonts.outfit(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Введите email';
                    }
                    return null;
                  },
                  controller: emailController,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    prefixIcon: const Icon(
                      Icons.email,
                      color: Colors.white70,
                    ),
                    hintText: "Email",
                    hintStyle: TextStyle(color: Colors.white70),
                    filled: true,
                    fillColor: Colors.grey[850],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                TextFormField(
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Введите пароль';
                    }
                    return null;
                  },
                  obscureText: true,
                  controller: passwordController,
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    prefixIcon: const Icon(
                      Icons.lock,
                      color: Colors.white70,
                    ),
                    hintText: "Пароль",
                    hintStyle: TextStyle(color: Colors.white70),
                    filled: true,
                    fillColor: Colors.grey[850],
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.bottomRight,
                  child: TextButton(
                    onPressed: () {
                      //TODO: Implement forgot password
                    },
                    child: Text(
                      'Забыли пароль?',
                      style: TextStyle(
                        color: Colors.blueAccent,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 40),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    minimumSize: Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: isLoading ? null : loginUser,
                  child: isLoading
                      ? const CircularProgressIndicator(
                    color: Colors.white,
                  )
                      : Text(
                    'Войти',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
                const SizedBox(height: 80),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Нет аккаунта?',
                      style: TextStyle(color: Colors.white70),
                    ),
                    TextButton(
                      onPressed: () {
                        Get.to(() => const RegisterScreen());
                      },
                      child: Text(
                        'Регистрация',
                        style: TextStyle(
                          color: Colors.blueAccent,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}