import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

class TrafficScreen extends StatefulWidget {
  const TrafficScreen({Key? key}) : super(key: key);

  @override
  State<TrafficScreen> createState() => _TrafficScreenState();
}

class _TrafficScreenState extends State<TrafficScreen> {
  static const platform = MethodChannel('com.app.mrx/traffic');
  int _totalUpload = 0;
  int _totalDownload = 0;
  bool _isObserving = false;
  late SharedPreferences _prefs;
  Map<String, Map<String, int>> _trafficData = {};
  final String _today = DateFormat('yyyy-MM-dd').format(DateTime.now());


  @override
  void initState() {
    super.initState();
    _initPrefsAndTrafficData();
    _startObserving();
  }


  Future<void> _initPrefsAndTrafficData() async {
    _prefs = await SharedPreferences.getInstance();
    _loadTrafficData();
  }

  Future<void> _loadTrafficData() async {
    setState(() {
      _trafficData = (_prefs.getString('trafficData') != null) ?  Map<String, Map<String, int>>.from(jsonDecode(_prefs.getString('trafficData')!)) : {};
    });
    debugPrint('Loaded traffic data: $_trafficData');
  }

  Future<void> _saveTrafficData() async {
    String json = jsonEncode(_trafficData);
    await _prefs.setString('trafficData', json);
    debugPrint('Saved traffic data: $json');
  }


  Future<void> _startObserving() async {
    try {
      await platform.invokeMethod('startObservingTraffic');
      _isObserving = true;
      _listenForTrafficUpdates();
    } on PlatformException catch (e) {
      debugPrint("Failed to start observing traffic: ${e.message}");
    }
  }


  Future<void> _stopObserving() async {
    try {
      await platform.invokeMethod('stopObservingTraffic');
      _isObserving = false;
    } on PlatformException catch (e) {
      debugPrint("Failed to stop observing traffic: ${e.message}");
    }
  }

  void _listenForTrafficUpdates() {
    platform.setMethodCallHandler((call) async {
      if (call.method == 'trafficUpdate') {
        final int totalUpload = call.arguments["totalUpload"];
        final int totalDownload = call.arguments["totalDownload"];
        _updateTrafficData(totalUpload, totalDownload);
      }
    });
  }


  void _updateTrafficData(int totalUpload, int totalDownload) {
    setState(() {
      _totalUpload = totalUpload;
      _totalDownload = totalDownload;
      if (_trafficData[_today] == null) {
        _trafficData[_today] = {'upload': 0, 'download': 0};
      }
      _trafficData[_today]!['upload'] = totalUpload;
      _trafficData[_today]!['download'] = totalDownload;
    });

    _saveTrafficData();
  }

  @override
  void dispose() {
    _stopObserving();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          "Статистика трафика",
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTrafficSection(
                title: 'Сегодня',
                upload: _trafficData[_today]?['upload'] ?? 0,
                download: _trafficData[_today]?['download'] ?? 0,
              ),
              SizedBox(height: 16),
              _buildTrafficSectionForMonth(),
              SizedBox(height: 16),
              ..._buildTrafficSectionsForOtherDays(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTrafficSection({required String title, required int upload, required int download}){
    return  Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontSize: 20,
          ),
        ),
        Text(
          "Upload: ${formatBytes(upload)}",
          style: GoogleFonts.outfit(
            color: Colors.white70,
            fontSize: 18,
          ),
        ),
        Text(
          "Download: ${formatBytes(download)}",
          style: GoogleFonts.outfit(
            color: Colors.white70,
            fontSize: 18,
          ),
        ),
      ],
    );
  }

  Widget _buildTrafficSectionForMonth() {
    final now = DateTime.now();
    final firstDayOfMonth = DateTime(now.year, now.month, 1);
    final lastDayOfMonth = DateTime(now.year, now.month + 1, 0);

    int totalMonthUpload = 0;
    int totalMonthDownload = 0;

    _trafficData.forEach((dateString, traffic) {
      DateTime date = DateTime.parse(dateString);
      if (date.isAfter(firstDayOfMonth.subtract(Duration(days: 1))) &&
          date.isBefore(lastDayOfMonth.add(Duration(days: 1)))) {
        totalMonthUpload += traffic['upload'] ?? 0;
        totalMonthDownload += traffic['download'] ?? 0;
      }
    });

    return _buildTrafficSection(
      title: 'За месяц',
      upload: totalMonthUpload,
      download: totalMonthDownload,
    );
  }

  List<Widget> _buildTrafficSectionsForOtherDays() {
    List<Widget> sections = [];
    _trafficData.forEach((dateString, traffic) {
      if (dateString != _today) {
        DateTime date = DateTime.parse(dateString);
        sections.add(
          _buildTrafficSection(
            title: DateFormat('dd MMMM yyyy').format(date),
            upload: traffic['upload'] ?? 0,
            download: traffic['download'] ?? 0,
          ),
        );
        sections.add(SizedBox(height: 16));
      }
    });
    return sections;
  }

  String formatBytes(int bytes) {
    if (bytes < 1024) {
      return "$bytes B";
    } else if (bytes < 1024 * 1024) {
      double kb = bytes / 1024;
      return "${kb.toStringAsFixed(2)} KB";
    } else if (bytes < 1024 * 1024 * 1024) {
      double mb = bytes / (1024 * 1024);
      return "${mb.toStringAsFixed(2)} MB";
    } else {
      double gb = bytes / (1024 * 1024 * 1024);
      return "${gb.toStringAsFixed(2)} GB";
    }
  }
}
