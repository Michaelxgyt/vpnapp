// lib/screen/home/home_screen.dart

import 'dart:io';
import 'dart:async';
import 'dart:math' as math;
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:device_info_plus/device_info_plus.dart'; // Добавляем импорт device_info_plus
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_v2ray/flutter_v2ray.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gamers_shield_vpn/screen/auth/profile_screen.dart';
import 'package:gamers_shield_vpn/screen/notification/notification_screen.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../utils/app_constant.dart';
import '../location/location_screen.dart';

// Определяем graphPlaceholderColor как глобальную константу
const Color graphPlaceholderColor = Colors.white38;

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  // --- Строковые константы для UI ---
  static const String connectedStatusText = "Подключено";
  static const String disconnectedStatusText = "Отключено";
  static const String connectingStatusText = "Подключение...";
  static const String disconnectingStatusText = "Отключение...";
  static const String selectLocationText = "Выберите локацию";

  // --- Цветовые константы ---
  static const Color connectedColor = Colors.greenAccent;
  static const Color disconnectedColor = Colors.redAccent;
  static const Color connectingColor = Colors.orangeAccent;

  // --- Таймауты и технические параметры ---
  static const int pingTimeoutSeconds = 5;
  static const int maxSpeedDataPoints = 60;

  // --- Константы для проверки обновлений ---
  static const String UPDATE_URL = 'https://github.com/Michaelxgyt/mrx.app/releases/download/v2rayng/mrx2.apk';
  static const String FIRESTORE_COLLECTION = 'versionapp';
  static const String FIRESTORE_DOCUMENT = 'version';
  // Обновляем имя поля для соответствия структуре вашей базы данных
  static const String VERSION_FIELD_NAME = 'version';

  // --- Данные о VPN-соединении ---
  late final FlutterV2ray flutterV2ray;
  final v2rayStatus = ValueNotifier<V2RayStatus>(V2RayStatus());
  String? _previousState;
  String? coreVersion;
  List<String> bypassSubnets = [];
  final TextEditingController bypassSubnetController = TextEditingController();

  // --- Данные о выбранном сервере ---
  bool isPro = false; // Используется без null
  String? serverName;
  String? config;
  String currentPing = "N/A"; // Убрал nullable, так как всегда инициализируем

  // --- Данные о подписке ---
  String? expiryDate;
  String remainingTimeFormatted = "Загрузка...";
  Color remainingTimeColor = Colors.white70; // Добавляем переменную для цвета времени
  Timer? _subscriptionTimer;

  // --- Флаги состояния ---
  bool _isPinging = false;
  bool _isLoading = false;

  // --- Управление UI ---
  Timer? _timer;
  final ValueNotifier<List<double>> _speedData = ValueNotifier<List<double>>([]);
  late AnimationController _connectionAnimationController;

  // --- Версии приложения ---
  String currentVersion = "";
  String latestVersion = "";

  @override
  void dispose() {
    v2rayStatus.dispose();
    bypassSubnetController.dispose();
    _connectionAnimationController.dispose();
    _speedData.dispose();
    _timer?.cancel(); // Добавлена отмена таймера при уничтожении объекта
    _subscriptionTimer?.cancel(); // Отменяем таймер подписки при уничтожении виджета
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _connectionAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    flutterV2ray = FlutterV2ray(
      onStatusChanged: _handleStatusChanged,
    );
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await loadConfigData();
      await _getExpiryDate();
      await _loadVersionsAndCheckUpdate(); // Новый метод

      try {
        await flutterV2ray.initializeV2Ray();
        coreVersion = await flutterV2ray.getCoreVersion();
        if (kDebugMode) {
          print("V2Ray Version: $coreVersion");
        }
        setState(() {});
      } catch (e) {
        if (kDebugMode) {
          print("Ошибка инициализации V2Ray: $e");
        }
      }
    });
  }

  // Убираем вызов _forceCheckForUpdates из _loadVersionsAndCheckUpdate
  Future<void> _loadVersionsAndCheckUpdate() async {
    if (kDebugMode) {
      print("[VERSION] Запуск _loadVersionsAndCheckUpdate");
    }
    await _loadCurrentVersion();
    await _fetchLatestVersion();

    // Проверяем обновления без показа сообщения при запуске (silent=true)
    await _checkVersionsForUpdate(silent: true);

    if (kDebugMode) {
      print("[VERSION] Завершение _loadVersionsAndCheckUpdate");
    }
  }

  // Улучшаем функцию загрузки текущей версии с подробным логированием
  Future<void> _loadCurrentVersion() async {
    if (kDebugMode) {
      print("[VERSION] Начинаю загрузку текущей версии приложения...");
    }
    try {
      final info = await PackageInfo.fromPlatform();
      if (kDebugMode) {
        print("[VERSION] Текущая версия получена из PackageInfo: ${info.version}");
      }
      setState(() {
        currentVersion = info.version;
      });
    } catch (e) {
      if (kDebugMode) {
        print("[VERSION] ⚠️ ОШИБКА при получении текущей версии: $e");
      }
      setState(() {
        currentVersion = "";
      });
    }
    if (kDebugMode) {
      print("[VERSION] Итоговая текущая версия: $currentVersion");
    }
  }

  // Улучшаем функцию загрузки последней версии с подробным логированием
  Future<void> _fetchLatestVersion() async {
    if (kDebugMode) {
      print("[VERSION] Начинаю загрузку последней версии из Firebase...");
      print("[VERSION] Коллекция: $FIRESTORE_COLLECTION, документ: $FIRESTORE_DOCUMENT, поле: $VERSION_FIELD_NAME");
    }
    try {
      if (kDebugMode) {
        print("[VERSION] Инициация запроса к Firestore...");
      }

      final doc = await FirebaseFirestore.instance
          .collection(FIRESTORE_COLLECTION)
          .doc(FIRESTORE_DOCUMENT)
          .get();

      if (kDebugMode) {
        print("[VERSION] Запрос к Firestore выполнен");
        print("[VERSION] Документ существует: ${doc.exists}");
        if (doc.exists) {
          print("[VERSION] Данные документа: ${doc.data()}");
        }
      }

      if (doc.exists && doc.data() != null) {
        // Проверяем поле 'version' вместо 'latest'
        if (doc.data()!.containsKey(VERSION_FIELD_NAME)) {
          if (kDebugMode) {
            print("[VERSION] Последняя версия найдена: ${doc.data()![VERSION_FIELD_NAME]}");
          }
          setState(() {
            latestVersion = doc.data()![VERSION_FIELD_NAME].toString();
          });
        } else {
          // Если поле 'version' не найдено, устанавливаем пустую строку
          if (kDebugMode) {
            print("[VERSION] ⚠️ Поле '$VERSION_FIELD_NAME' не найдено в документе");
          }
          setState(() {
            latestVersion = "";
          });
        }
      } else {
        if (kDebugMode) {
          print("[VERSION] ⚠️ Документ не существует или null");
        }
        // Если документа нет, устанавливаем пустую строку
        setState(() {
          latestVersion = "";
        });
      }
    } catch (e) {
      if (kDebugMode) {
        print("[VERSION] ⚠️ ОШИБКА при получении последней версии из Firebase: $e");
        print("[VERSION] ${e.runtimeType}: ${e.toString()}");

        // Проверка подключения к Firebase
        try {
          print("[VERSION] Проверка соединения с Firebase...");
          bool isConnected = await _checkFirebaseConnection();
          print("[VERSION] Firebase соединение: ${isConnected ? 'АКТИВНО' : 'НЕ АКТИВНО'}");
        } catch (connectionError) {
          print("[VERSION] Ошибка при проверке соединения: $connectionError");
        }
      }
      // В случае ошибки устанавливаем пустую строку
      setState(() {
        latestVersion = "";
      });
    }
    if (kDebugMode) {
      print("[VERSION] Итоговая последняя версия: $latestVersion");
    }
  }

  // Улучшаем метод проверки соединения с Firebase - проверяем через коллекцию users
  Future<bool> _checkFirebaseConnection() async {
    try {
      // Попробуем проверить соединение через коллекцию users, которая наверняка есть
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('users')
          .limit(1)
          .get();

      if (kDebugMode) {
        print("[VERSION] Проверка соединения: получено ${snapshot.docs.length} документов из 'users'");
      }

      return snapshot.docs.isNotEmpty; // Если есть хотя бы один документ, соединение работает
    } catch (e) {
      if (kDebugMode) {
        print("[VERSION] Ошибка проверки соединения с Firebase: $e");
      }
      return false;
    }
  }

  // Переименовываем _forceCheckForUpdates и добавляем параметр silent
  // для контроля показа уведомлений
  Future<void> _checkVersionsForUpdate({bool silent = false}) async {
    if (kDebugMode) {
      print("\n[VERSION] ======== ПРОВЕРКА ОБНОВЛЕНИЙ ========");
      print("[VERSION] Текущая версия до проверки: '$currentVersion'");
      print("[VERSION] Последняя версия до проверки: '$latestVersion'");
    }

    try {
      // Если версии не загружены, загружаем их
      if (currentVersion.isEmpty) {
        if (kDebugMode) print("[VERSION] Текущая версия пуста, загружаю...");
        await _loadCurrentVersion();
      }

      if (latestVersion.isEmpty) {
        if (kDebugMode) print("[VERSION] Последняя версия пуста, загружаю...");
        await _fetchLatestVersion();
      }

      // Повторная проверка после загрузки
      if (kDebugMode) {
        print("[VERSION] После загрузки:");
        print("[VERSION] Текущая версия: '$currentVersion'");
        print("[VERSION] Последняя версия: '$latestVersion'");
      }

      if (currentVersion.isEmpty || latestVersion.isEmpty) {
        if (kDebugMode) {
          print("[VERSION] ⚠️ Не удалось загрузить версии после попытки");
          print("[VERSION] currentVersion пустая: ${currentVersion.isEmpty}");
          print("[VERSION] latestVersion пустая: ${latestVersion.isEmpty}");
        }
        return;
      }

      // Сравниваем версии
      if (kDebugMode) {
        print("[VERSION] Сравнение версий: '$currentVersion' vs '$latestVersion'");
        print("[VERSION] Равны: ${currentVersion == latestVersion}");
      }

      if (currentVersion != latestVersion && mounted) {
        if (kDebugMode) {
          print("[VERSION] ✅ Обнаружена новая версия! Показываю диалог обновления");
        }
        _showUpdateDialog(latestVersion);
      } else {
        if (kDebugMode) {
          print("[VERSION] ✅ У вас установлена последняя версия приложения");
        }

        // Показываем сообщение только если это не тихая проверка (silent = false)
        if (!silent && mounted) {
          // Используем только стильное уведомление SnackBar
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  Icon(Icons.check_circle, color: Colors.white),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      "У вас установлена последняя версия приложения (${currentVersion})",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
              backgroundColor: Colors.green[700],
              duration: Duration(seconds: 3),
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.all(16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          );
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("[VERSION] ⚠️ ОШИБКА при проверке обновлений: $e");
        print("[VERSION] ${e.runtimeType}: ${e.toString()}");
      }
    }
  }

  Future<void> loadConfigData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      serverName = prefs.getString('serverName');
      config = prefs.getString('config');
      isPro = prefs.getBool('isPro') ?? false;
    });
    if (kDebugMode) {
      print("Server: $serverName, Config:, Pro: $isPro");
    }
  }

  Future<void> _getExpiryDate() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? expiryDateString = prefs.getString("expiryDate");

    if (expiryDateString != null && expiryDateString.isNotEmpty) {
      setState(() {
        expiryDate = expiryDateString;
      });
      _startCountdownTimer();
    } else {
      String? userId = prefs.getString("token");
      if (userId != null) {
        try {
          DocumentSnapshot userDoc = await FirebaseFirestore.instance
              .collection('users')
              .doc(userId)
              .get();

          if (userDoc.exists) {
            Map<String, dynamic>? userData = userDoc.data() as Map<String, dynamic>?;
            if (userData != null && userData.containsKey('expiryDate') && userData['expiryDate'] is Timestamp) {
              expiryDate = (userData['expiryDate'] as Timestamp).toDate().toIso8601String();
              await prefs.setString("expiryDate", expiryDate!);
              _startCountdownTimer();
            } else {
              setState(() {
                remainingTimeFormatted = "Нет данных";
              });
            }
          } else {
            setState(() {
              remainingTimeFormatted = "Нет данных";
            });
          }
        } catch (e) {
          if (kDebugMode) {
            print("Ошибка при получении даты окончания подписки: $e");
          }
          setState(() {
            remainingTimeFormatted = "Ошибка";
          });
        }
      }
    }
  }

  void _startCountdownTimer() {
    if (expiryDate == null) {
      setState(() {
        remainingTimeFormatted = "Нет данных о подписке";
        remainingTimeColor = Colors.white70;
      });
      return;
    }

    try {
      final expiry = DateTime.parse(expiryDate!);
      _subscriptionTimer?.cancel(); // Отменяем предыдущий таймер если он существует

      _subscriptionTimer = Timer.periodic(Duration(seconds: 1), (timer) {
        if (!mounted) {
          timer.cancel();
          return;
        }

        final now = DateTime.now();

        if (now.isAfter(expiry)) {
          setState(() {
            remainingTimeFormatted = "Срок подписки истек";
            remainingTimeColor = Colors.red; // Красный цвет для истекшей подписки
          });
          timer.cancel();
          return;
        }

        final difference = expiry.difference(now);
        final days = difference.inDays;
        final hours = difference.inHours % 24;
        final minutes = difference.inMinutes % 60;
        final seconds = difference.inSeconds % 60;

        // Определяем цвет в зависимости от оставшегося времени
        Color newColor;
        if (days < 1) {
          newColor = Colors.red; // Красный если осталось менее 1 дня
        } else if (days < 2) {
          newColor = Colors.amber; // Желтый если осталось менее 2 дней
        } else {
          newColor = Colors.white70; // Стандартный цвет в других случаях
        }

        setState(() {
          remainingTimeFormatted = "$days д $hours ч $minutes м $seconds с";
          remainingTimeColor = newColor;
        });
      });
    } catch (e) {
      if (kDebugMode) {
        print("Ошибка при запуске таймера: $e");
      }
      setState(() {
        remainingTimeFormatted = "Ошибка таймера";
        remainingTimeColor = Colors.white70;
      });
    }
  }

  void _handleStatusChanged(V2RayStatus status) async {
    v2rayStatus.value = status;

    // Обновление графика скорости
    List<double> currentSpeedData = List.from(_speedData.value);
    if (currentSpeedData.length >= maxSpeedDataPoints) {
      currentSpeedData.removeAt(0);
    }
    currentSpeedData.add(status.downloadSpeed.toDouble());
    _speedData.value = currentSpeedData;
    if (kDebugMode) {
      //print("handleStatusChanged - Speed Data: ${_speedData.value}, Download Speed: ${status.downloadSpeed}"); // Enhanced log
    }

    // Сохранение трафика
    await _saveCurrentTraffic(status.upload, status.download);

    if (_previousState != status.state) {
      _previousState = status.state;
      await _updateUserStatus(status.state);
      if (status.state == "CONNECTED") {
        _connectionAnimationController.forward();
      } else {
        _connectionAnimationController.reverse();
      }
    }
  }

  String formatBytes(int bytes, {int decimals = 2}) {
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB"];
    int i = (math.log(bytes) / math.log(1024)).floor();
    if (i >= suffixes.length) i = suffixes.length - 1;
    double size = bytes / math.pow(1024, i);
    return '${size.toStringAsFixed(decimals)} ${suffixes[i]}';
  }

  Future<void> _saveCurrentTraffic(int uploadBytes, int downloadBytes) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      double uploadInMB = uploadBytes / (1024 * 1024);
      double downloadInMB = downloadBytes / (1024 * 1024);
      await prefs.setDouble("currentUpload", uploadInMB);
      await prefs.setDouble("currentDownload", downloadInMB);
      if (kDebugMode) {}
    } catch (e) {
      if (kDebugMode) {
        print("Ошибка при сохранении текущего трафика: $e");
      }
    }
  }

  Future<void> _updateUserStatus(String state) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? userId = prefs.getString("token");
      if (userId != null) {
        String newStatus = state == "CONNECTED" ? "active" : "inactive";
        await FirebaseFirestore.instance.collection('users').doc(userId).update({'status': newStatus});
        if (kDebugMode) {
          print("Статус пользователя обновлён: $newStatus");
        }
      } else {
        if (kDebugMode) {
          print("Ошибка: Токен пользователя не найден.");
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("Ошибка обновления статуса пользователя: $e");
      }
    }
  }

  Future<Map<String, dynamic>?> fetchUserProfile(String id) async {
    try {
      if (kDebugMode) {
        print("Получение профиля пользователя с ID: $id");
      }
      QuerySnapshot snapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('uid', isEqualTo: id)
          .get();
      if (snapshot.docs.isNotEmpty) {
        return snapshot.docs.first.data() as Map<String, dynamic>;
      } else {
        if (kDebugMode) {
          print("Профиль пользователя не найден.");
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print("Ошибка при получении профиля пользователя: $e");
      }
    }
    return null;
  }

  void bypassSubnet() {
    bypassSubnetController.text = bypassSubnets.join("\n");
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.grey[850],
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Subnets:',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: bypassSubnetController,
                maxLines: 5,
                minLines: 3,
                style: TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  border: OutlineInputBorder(borderSide: BorderSide(color: Colors.white38)),
                  focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.blueAccent)),
                  hintStyle: TextStyle(color: Colors.white54),
                ),
              ),
              const SizedBox(height: 16),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
                onPressed: () {
                  bypassSubnets = bypassSubnetController.text.trim().split('\n');
                  if (bypassSubnets.first.isEmpty) {
                    bypassSubnets = [];
                  }
                  Navigator.of(context).pop();
                },
                child: Text('Submit', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _checkPingAndUpdateTmping() async {
    if (config == null || _isPinging) { // Проверяем _isPinging и config
      return;
    }

    setState(() {
      _isPinging = true; // Устанавливаем состояние "проверка пинга в процессе"
      currentPing = "Проверка..."; // Отображаем "Проверка..." пока идет пинг
    });

    String? host;
    int? port;

    // Extract host and port from config URL (без изменений)
    if (config!.startsWith("vmess://")) {
      try {
        String base64Config = config!.substring(8);
        String decodedConfig = utf8.decode(base64.decode(base64Config));
        Map<String, dynamic> configJson = json.decode(decodedConfig);
        host = configJson["add"];
        port = configJson["port"] != null ? int.tryParse(configJson["port"].toString()) : null;
      } catch (e) {
        if (kDebugMode) {
          print("Error parsing vmess config: $e");
        }
        setState(() {
          currentPing = "Ошибка"; // Отображаем "Ошибка" в случае ошибки разбора
          _isPinging = false; // Сбрасываем состояние проверки пинга
        });
        return;
      }
    } else if (config!.startsWith("vless://")) {
      try {
        Uri uri = Uri.parse(config!);
        host = uri.host;
        port = uri.port;
      } catch (e) {
        if (kDebugMode) {
          print("Error parsing vless config: $e");
        }
        setState(() {
          currentPing = "Ошибка"; // Отображаем "Ошибка" в случае ошибки разбора
          _isPinging = false; // Сбрасываем состояние проверки пинга
        });
        return;
      }
    } else {
      if (kDebugMode) {
        print("Unsupported config format: $config");
      }
      setState(() {
        currentPing = "N/A";
        _isPinging = false; // Сбрасываем состояние проверки пинга
      });
      return;
    }

    if (host == null || port == null) {
      if (kDebugMode) {
        print("Could not extract host or port from config: $config");
      }
      setState(() {
        currentPing = "N/A";
        _isPinging = false; // Сбрасываем состояние проверки пинга
      });
      return;
    }

    Stopwatch stopwatch = Stopwatch()..start();
    try {
      Socket socket = await Socket.connect(host, port, timeout: Duration(seconds: pingTimeoutSeconds));
      stopwatch.stop();
      socket.destroy();
      int latency = stopwatch.elapsedMilliseconds;
      if (kDebugMode) {
        print("Ping to $host:$port successful: ${latency}ms");
      }
      setState(() {
        currentPing = "${latency}ms"; // Отображаем результат пинга
        _isPinging = false; // Сбрасываем состояние проверки пинга
      });
    } catch (e) {
      stopwatch.stop();
      if (kDebugMode) {
        print("Ping to $host:$port failed: Timeout or error - $e");
      }
      setState(() {
        currentPing = "Таймаут"; // Отображаем "Таймаут" в случае неудачи
        _isPinging = false; // Сбрасываем состояние проверки пинга
      });
    }
  }

  Future<void> _checkUserProStatusOnDemand() async {
    setState(() {
      _isLoading = true; // Начинаем загрузку, чтобы показать индикатор во время проверки
    });

    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String? userId = prefs.getString("token");

      if (userId != null) {
        if (kDebugMode) {
          print("Проверка статуса пользователя при нажатии кнопки. ID: $userId");
        }
        var userProfile = await fetchUserProfile(userId);

        if (userProfile != null && userProfile['type'] != null) {
          if (kDebugMode) {
            print("Тип пользователя: ${userProfile['type']}");
          }
          if (isPro == true && userProfile['type'] != "Pro") {
            if (kDebugMode) {
              print("Пользователь больше не Pro. Остановка V2Ray.");
            }
            await flutterV2ray.stopV2Ray();
            v2rayStatus.value = V2RayStatus(state: "DISCONNECTED");
            setState(() {
              serverName = null;
              config = null;
              isPro = false; // Correctly set isPro to false
              currentPing = "N/A";
              _isLoading = false; // Сбрасываем состояние загрузки
              _connectionAnimationController.reverse(); // Реверс анимации
            });

            await prefs.remove('serverName');
            await prefs.remove('config');
            await prefs.setBool('isPro', false); // Ensure isPro is set to false in SharedPreferences

            Fluttertoast.showToast(
              msg: "Ваш Pro статус истек. VPN отключен.",
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.BOTTOM,
              backgroundColor: Colors.orangeAccent,
              textColor: Colors.black,
              fontSize: 16.0,
            );
          } else {
            setState(() {
              _isLoading = false; // Сбрасываем состояние загрузки если статус Pro в порядке
            });
          }
        } else {
          if (kDebugMode) {
            print("Ошибка: Профиль пользователя не найден.");
          }
          await flutterV2ray.stopV2Ray();
          v2rayStatus.value = V2RayStatus(state: "DISCONNECTED");
          setState(() {
            _isLoading = false; // Сбрасываем состояние загрузки
            _connectionAnimationController.reverse(); // Реверс анимации
          });
          Fluttertoast.showToast(
            msg: "Ошибка: Профиль пользователя не найден. VPN отключен.",
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            backgroundColor: Colors.redAccent,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
      } else {
        if (kDebugMode) {
          print("Ошибка: Токен пользователя не найден.");
        }
        setState(() {
          _isLoading = false; // Сбрасываем состояние загрузки
          _connectionAnimationController.reverse(); // Реверс анимации
        });
        Fluttertoast.showToast(
          msg: "Ошибка авторизации. Пожалуйста, войдите снова.",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0,
        );
      }
    } catch (e) {
      if (kDebugMode) {
        print("Ошибка при проверке статуса пользователя: $e");
      }
      setState(() {
        _isLoading = false; // Сбрасываем состояние загрузки
        _connectionAnimationController.reverse(); // Реверс анимации
      });
      Fluttertoast.showToast(
        msg: "Ошибка при проверке статуса. Попробуйте позже.",
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.grey,
        textColor: Colors.white,
        fontSize: 16.0,
      );
    }
  }

  // Диалог с предложением обновления
  void _showUpdateDialog(String newVersion) {
    if (kDebugMode) {
      print("[VERSION] Вызван метод _showUpdateDialog с версией $newVersion");
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        if (kDebugMode) {
          print("[VERSION] Создание диалогового окна обновления");
        }
        return AlertDialog(
          backgroundColor: Colors.grey[850],
          title: Text(
            'Доступно обновление',
            style: TextStyle(color: Colors.white),
          ),
          content: Text(
            'Доступна новая версия приложения $newVersion. Обновите приложение чтобы получить последние функции и исправления.',
            style: TextStyle(color: Colors.white70),
          ),
          actions: [
            TextButton(
              onPressed: () {
                if (kDebugMode) {
                  print("[VERSION] Нажата кнопка 'Позже'");
                }
                Navigator.of(context).pop();
              },
              child: Text(
                'Позже',
                style: TextStyle(color: Colors.white70),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
              ),
              onPressed: () {
                if (kDebugMode) {
                  print("[VERSION] Нажата кнопка 'Обновить'");
                }
                Navigator.of(context).pop();
                _downloadUpdate();
              },
              child: Text(
                'Обновить',
                style: TextStyle(color: Colors.white),
              ),
            ),
          ],
        );
      },
    );
  }

  // Модифицированный метод скачивания, использующий директорию Downloads вместо app_flutter
  Future<void> _downloadUpdate() async {
    // Простая последовательность запроса разрешений
    try {
      if (kDebugMode) {
        print("Запрашиваем разрешения на запись...");
      }

      // Запрос необходимых разрешений для Android
      if (Platform.isAndroid) {
        final sdkInt = await _getAndroidSdkVersion();

        if (kDebugMode) {
          print("Android SDK: $sdkInt");
        }

        // Запрашиваем соответствующие разрешения в зависимости от версии Android
        var storagePermissionGranted = false;

        if (sdkInt >= 33) {
          // Android 13+: используем READ_MEDIA_*
          final photosStatus = await Permission.photos.request();
          if (kDebugMode) {
            print("Статус разрешения photos: $photosStatus");
          }
          storagePermissionGranted = photosStatus.isGranted;
        } else {
          // Более старые версии: используем storage
          final storageStatus = await Permission.storage.request();
          if (kDebugMode) {
            print("Статус разрешения storage: $storageStatus");
          }
          storagePermissionGranted = storageStatus.isGranted;
        }

        // Запрашиваем разрешение на установку приложений
        final installStatus = await Permission.requestInstallPackages.request();
        if (kDebugMode) {
          print("Статус разрешения на установку: $installStatus");
        }

        if (!storagePermissionGranted) {
          Fluttertoast.showToast(
            msg: "Необходим доступ к хранилищу для загрузки обновления",
            toastLength: Toast.LENGTH_LONG,
            backgroundColor: Colors.redAccent,
          );
          return;
        }

        if (!installStatus.isGranted) {
          Fluttertoast.showToast(
            msg: "Необходимо разрешение на установку приложений",
            toastLength: Toast.LENGTH_LONG,
            backgroundColor: Colors.redAccent,
          );
          return;
        }
      }

      // Определяем подходящую директорию для скачивания
      Directory? directory;

      try {
        if (Platform.isAndroid) {
          // Пытаемся использовать общедоступную директорию загрузок
          directory = await getExternalStorageDirectory();

          // Если не получилось, используем директорию приложения (временную)
          if (directory == null) {
            directory = await getApplicationDocumentsDirectory();
          }

          if (kDebugMode) {
            print("Директория для загрузки: ${directory.path}");
          }
        } else {
          directory = await getApplicationDocumentsDirectory();
        }
      } catch (e) {
        if (kDebugMode) {
          print("Ошибка при получении директории: $e");
        }
        directory = await getTemporaryDirectory();
      }

      if (directory == null) {
        Fluttertoast.showToast(
          msg: "Не удалось получить доступ к хранилищу",
          toastLength: Toast.LENGTH_LONG,
          backgroundColor: Colors.redAccent,
        );
        return;
      }

      // Показываем сообщение о начале загрузки
      Fluttertoast.showToast(
        msg: "Начинается загрузка обновления...",
        toastLength: Toast.LENGTH_LONG,
        backgroundColor: Colors.green,
      );

      // Запускаем загрузку в общедоступную директорию
      final taskId = await FlutterDownloader.enqueue(
          url: UPDATE_URL,
          savedDir: directory.path,
          fileName: "mrx_update.apk",
          showNotification: true,
          openFileFromNotification: true,
          saveInPublicStorage: true // Сохраняем в публичную директорию
      );

      if (kDebugMode) {
        print("Загрузка запущена с ID: $taskId в директорию ${directory.path}");
      }

    } catch (e) {
      if (kDebugMode) {
        print("Ошибка при загрузке обновления: $e");
      }
      Fluttertoast.showToast(
        msg: "Ошибка при загрузке обновления: $e",
        toastLength: Toast.LENGTH_LONG,
        backgroundColor: Colors.redAccent,
      );
    }
  }

  // Добавьте этот метод в класс _HomeScreenState
  Future<int> _getAndroidSdkVersion() async {
    if (Platform.isAndroid) {
      try {
        final DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
        final AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
        return androidInfo.version.sdkInt;
      } catch (e) {
        if (kDebugMode) {
          print("Ошибка при получении версии Android: $e");
        }
        return 0;
      }
    }
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: _buildAppBar(),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: _buildBodyContent(width),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      centerTitle: true,
      elevation: 0,
      backgroundColor: Colors.transparent,
      title: Text(
        "MRX VPN",
        style: GoogleFonts.raleway(
          fontSize: 28,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
      automaticallyImplyLeading: false,
      leading: IconButton(
        icon: const Icon(Icons.person_outline, color: Colors.white),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const MyProfileScreen()),
          );
        },
      ),
      actions: [
        // Добавляем кнопку проверки обновлений в AppBar
        IconButton(
          icon: const Icon(Icons.download, color: Colors.white),
          tooltip: 'Проверить обновления',
          onPressed: () {
            if (kDebugMode) {
              print("Ручная проверка обновлений...");
            }
            // Используем silent: false для явного показа сообщений при ручной проверке
            _checkVersionsForUpdate(silent: false);
          },
        ),
        IconButton(
          icon: const Icon(Icons.notifications_active, color: Colors.white),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const NotificationScreen()),
            );
          },
        ),
      ],
    );
  }

  Widget _buildBodyContent(double width) {
    return ValueListenableBuilder(
      valueListenable: v2rayStatus,
      builder: (context, V2RayStatus value, child) {
        final uploadFormatted = formatBytes(value.upload);
        final downloadFormatted = formatBytes(value.download);
        final uploadSpeedFormatted = '${formatBytes(value.uploadSpeed)}/s';
        final downloadSpeedFormatted = '${formatBytes(value.downloadSpeed)}/s';
        String connectionStatusText;
        Color connectionStatusColor;

        if (_isLoading) {
          connectionStatusText = connectingStatusText;
          connectionStatusColor = connectingColor;
        } else {
          switch (value.state) {
            case "CONNECTED":
              connectionStatusText = connectedStatusText;
              connectionStatusColor = connectedColor;
              break;
            case "DISCONNECTING":
              connectionStatusText = disconnectingStatusText;
              connectionStatusColor = disconnectedColor; // Можно сделать другой цвет
              break;
            default:
              connectionStatusText = disconnectedStatusText;
              connectionStatusColor = disconnectedColor;
              break;
          }
        }

        return SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildProStatusBanner(), // Баннер Pro статуса (теперь включает время подписки)
              const SizedBox(height: 24),
              _buildPowerButton(width, value, connectionStatusColor),
              const SizedBox(height: 32),
              _buildConnectionStatus(connectionStatusText, connectionStatusColor),
              const SizedBox(height: 20),
              _buildDurationAndTraffic(value, uploadFormatted, downloadFormatted),
              const SizedBox(height: 24),
              _buildServerLocationButton(value),
              const SizedBox(height: 32),
              _buildSpeedGraph(), // График скорости
              const SizedBox(height: 24),
              _buildSpeedStats(uploadSpeedFormatted, downloadSpeedFormatted),
              const SizedBox(height: 24),
              _buildPingDisplay(), // Отображение пинга
            ],
          ),
        );
      },
    );
  }

  Widget _buildProStatusBanner() {
    return isPro == true
        ? Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.grey[850],
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.amber[700]!, width: 1.5),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Pro статус
          Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.star, color: Colors.amber[700], size: 20),
              const SizedBox(width: 8),
              Text(
                "Pro Status Active",
                style: GoogleFonts.raleway(
                  color: Colors.amber[700],
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          // Добавляем время подписки ниже статуса с динамическим цветом
          if (remainingTimeFormatted.isNotEmpty) ...[
            const SizedBox(height: 8),
            Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.access_time, color: remainingTimeColor, size: 16),
                const SizedBox(width: 8),
                Text(
                  "До окончания: $remainingTimeFormatted",
                  style: TextStyle(
                    color: remainingTimeColor, // Используем динамический цвет
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    )
        : const SizedBox.shrink();
  }

  Widget _buildPowerButton(double width, V2RayStatus value, Color connectionStatusColor) {
    return GestureDetector(
      onTap: _isLoading
          ? null
          : () async {
        if (config != null) {
          setState(() {
            _isLoading = true; // Начинаем загрузку при нажатии кнопки
          });
          if (value.state == "DISCONNECTED" || value.state == "DISCONNECTING") {
            await _checkUserProStatusOnDemand();
            if (v2rayStatus.value.state == "DISCONNECTED" || v2rayStatus.value.state == "DISCONNECTING") {
              await _checkPingAndUpdateTmping(); // Проверяем пинг перед подключением
              V2RayURL parser = FlutterV2ray.parseFromURL(config!);
              if (await flutterV2ray.requestPermission()) {
                try {
                  await flutterV2ray.startV2Ray(
                    remark: parser.remark,
                    config: parser.getFullConfiguration(),
                    proxyOnly: false,
                    bypassSubnets: bypassSubnets,
                  );
                  if (kDebugMode) {
                    print("V2Ray запущен успешно.");
                  }
                } catch (e) {
                  if (kDebugMode) {
                    print("Ошибка при запуске V2Ray: $e");
                  }
                  Fluttertoast.showToast(
                    msg: "Не удалось запустить VPN.",
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.BOTTOM,
                    timeInSecForIosWeb: 1,
                    backgroundColor: Colors.red,
                    textColor: Colors.white,
                    fontSize: 16.0,
                  );
                }
              }
            }
          } else {
            await flutterV2ray.stopV2Ray();
            if (kDebugMode) {
              print("V2Ray остановлен.");
            }
          }
          setState(() {
            _isLoading = false; // Завершаем загрузку после попытки подключения/отключения
          });
        } else {
          Fluttertoast.showToast(
            msg: "Пожалуйста, выберите локацию",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0,
          );
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        height: width * 0.35,
        width: width * 0.35,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: connectionStatusColor, // Цвет кнопки меняется в зависимости от статуса
          boxShadow: [
            BoxShadow(
              color: connectionStatusColor.withOpacity(0.5),
              spreadRadius: 5,
              blurRadius: 15,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Center(
          child: _isLoading
              ? const CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
          )
              : AnimatedIcon(
            icon: AnimatedIcons.play_pause,
            progress: _connectionAnimationController,
            color: Colors.white,
            size: 70,
          ),
        ),
      ),
    );
  }

  Widget _buildConnectionStatus(String connectionStatusText, Color connectionStatusColor) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      transitionBuilder: (Widget child, Animation<double> animation) {
        return FadeTransition(opacity: animation, child: child);
      },
      child: Text(
        connectionStatusText,
        key: ValueKey<String>(connectionStatusText), // Key для AnimatedSwitcher
        style: GoogleFonts.raleway(
          fontSize: 32,
          fontWeight: FontWeight.bold,
          color: connectionStatusColor,
        ),
      ),
    );
  }

  Widget _buildDurationAndTraffic(V2RayStatus value, String uploadFormatted, String downloadFormatted) {
    return Column(
      children: [
        Text(
          'Длительность: ${value.duration}',
          style: TextStyle(fontSize: 16, color: Colors.white70),
        ),
        const SizedBox(height: 8),
        Text(
          'Трафик: $uploadFormatted↑  $downloadFormatted↓',
          style: TextStyle(fontSize: 16, color: Colors.white70),
        ),
      ],
    );
  }

  Widget _buildServerLocationButton(V2RayStatus status) {
    return ElevatedButton.icon(
      onPressed: () {
        // Переходим на экран выбора сервера без отключения текущего VPN
        Get.to(() => LocationScreen(), transition: Transition.rightToLeft)?.then((_) async {
          // После возвращения с экрана локаций
          String? oldConfig = config; // Сохраняем старую конфигурацию для сравнения
          await loadConfigData(); // Загружаем новые данные о сервере
          
          // Если был выбран новый сервер (конфигурация изменилась)
          if (config != null && config != oldConfig) {
            if (kDebugMode) {
              print("Выбран новый сервер: $serverName");
            }
            
            // Если VPN активно, переключаемся на новый сервер
            if (status.state == "CONNECTED" || status.state == "CONNECTING") {
              setState(() {
                _isLoading = true; // Показываем индикатор загрузки
              });
              
              // Отключаем текущее VPN соединение
              await flutterV2ray.stopV2Ray();
              if (kDebugMode) {
                print("VPN отключен для переключения на новый сервер");
              }
              
              // Подключаемся к новому серверу
              await _checkPingAndUpdateTmping(); // Проверяем пинг перед подключением
              V2RayURL parser = FlutterV2ray.parseFromURL(config!);
              
              if (await flutterV2ray.requestPermission()) {
                try {
                  await flutterV2ray.startV2Ray(
                    remark: parser.remark,
                    config: parser.getFullConfiguration(),
                    proxyOnly: false,
                    bypassSubnets: bypassSubnets,
                  );
                  if (kDebugMode) {
                    print("VPN переключен на новый сервер: $serverName");
                  }
                  
                  Fluttertoast.showToast(
                    msg: "Подключено к серверу: $serverName",
                    toastLength: Toast.LENGTH_SHORT, 
                    gravity: ToastGravity.BOTTOM,
                    backgroundColor: Colors.green,
                    textColor: Colors.white,
                  );
                } catch (e) {
                  if (kDebugMode) {
                    print("Ошибка при подключении к новому серверу: $e");
                  }
                  Fluttertoast.showToast(
                    msg: "Не удалось подключиться к новому серверу",
                    toastLength: Toast.LENGTH_SHORT, 
                    gravity: ToastGravity.BOTTOM,
                    backgroundColor: Colors.red,
                    textColor: Colors.white,
                  );
                }
              }
              
              setState(() {
                _isLoading = false; // Скрываем индикатор загрузки
              });
            }
          }
        });
      },
      icon: const Icon(Icons.public, color: Colors.white70),
      label: Text(
        serverName != null ? "$serverName" : selectLocationText,
        style: const TextStyle(color: Colors.white70, fontSize: 18),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.grey[850],
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: Colors.white24)),
      ),
    );
  }

  Widget _buildSpeedGraph() {
    return ValueListenableBuilder<List<double>>(
      valueListenable: _speedData,
      builder: (context, speedData, child) {
        if (kDebugMode) {
          // print("buildSpeedGraph - Rebuilding with data count: ${speedData.length}, Data: $speedData"); // Enhanced log
        }
        return Container(
          width: double.infinity, // **Занимает всю доступную ширину**
          height: 80, // Высота графика
          decoration: BoxDecoration( // Добавляем decoration для фона графика
            border: Border.all(color: graphPlaceholderColor), // Граница для placeholder
            borderRadius: BorderRadius.circular(5), // Опционально: скругление углов
            color: Colors.grey[850], // Цвет фона графика
          ),
          child: CustomPaint(
            painter: SpeedGraphPainter(speedData, Colors.blueAccent),
          ),
        );
      },
    );
  }

  Widget _buildSpeedStats(String uploadSpeedFormatted, String downloadSpeedFormatted) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildSpeedColumn(Icons.arrow_upward, Colors.greenAccent, 'Загрузка', uploadSpeedFormatted),
        _buildSpeedColumn(Icons.arrow_downward, Colors.redAccent, 'Скачивание', downloadSpeedFormatted),
      ],
    );
  }

  Widget _buildSpeedColumn(IconData icon, Color color, String label, String speed) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(color: Colors.white70, fontSize: 16),
          textAlign: TextAlign.center,
        ),
        Text(
          speed,
          style: TextStyle(color: Colors.white70, fontSize: 16, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildPingDisplay() {
    return GestureDetector( // Оборачиваем GestureDetector
      onTap: _isPinging ? null : _checkPingAndUpdateTmping, // Вызываем _checkPingAndUpdateTmping при нажатии, если не идет проверка
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.network_ping, color: Colors.white70),
          const SizedBox(width: 8),
          Text(
            "Пинг: $currentPing", // Отображаем currentPing
            style: const TextStyle(color: Colors.white70, fontSize: 16),
          ),
        ],
      ),
    );
  }
}

class SpeedGraphPainter extends CustomPainter {
  final List<double> speedData;
  final Color graphColor;
  static const Color graphPlaceholderColor = Colors.white38; // Placeholder color here too if needed in painter directly

  SpeedGraphPainter(this.speedData, this.graphColor);

  @override
  void paint(Canvas canvas, Size size) {
    // Рисуем placeholder сетку, даже если нет данных
    _drawPlaceholderGrid(canvas, size);

    if (speedData.isEmpty || size.width <= 0) return;

    double maxSpeed = speedData.reduce((a, b) => a > b ? a : b);
    if (maxSpeed == 0) maxSpeed = 1;

    final paint = Paint()
      ..color = graphColor
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    double widthPerDataPoint = size.width / (speedData.length - 1 < 1 ? 1 : speedData.length - 1);

    final path = Path(); // Path для волнового графика

    if (speedData.isNotEmpty) {
      // Начинаем путь с первой точки
      double startX = 0;
      double startY = size.height - (speedData[0] / maxSpeed * size.height).clamp(0, size.height);
      path.moveTo(startX, startY);

      // Соединяем все точки линиями для волнового графика
      for (int i = 1; i < speedData.length; i++) {
        double x = startX + widthPerDataPoint * i;
        double y = size.height - (speedData[i] / maxSpeed * size.height).clamp(0, size.height);
        path.lineTo(x, y);
        if (kDebugMode) {
          //print("SpeedGraphPainter - Point: index=$i, speed=${speedData[i]}, x=$x, y=$y, maxSpeed=$maxSpeed, widthPerDataPoint=$widthPerDataPoint");
        }
      }
      
      // Создаем расширенный красивый градиентный фон под графиком
      final fillPath = Path.from(path);
      fillPath.lineTo(size.width, size.height); // Нижний правый угол
      fillPath.lineTo(0, size.height); // Нижний левый угол
      fillPath.close();
      
      final fillPaint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            graphColor.withOpacity(0.7),  // Увеличили непрозрачность
            graphColor.withOpacity(0.4),  // Добавили промежуточный цвет
            graphColor.withOpacity(0.1),
          ],
          stops: const [0.0, 0.5, 1.0],   // Точки остановки для плавного перехода
        ).createShader(Rect.fromLTWH(0, 0, size.width, size.height))
        ..style = PaintingStyle.fill;
      
      canvas.drawPath(fillPath, fillPaint); // Рисуем заполнение
      
      // Улучшенный эффект свечения для линии с двумя слоями
      final outerGlowPaint = Paint()
        ..color = graphColor.withOpacity(0.2)
        ..strokeWidth = 6
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6)
        ..style = PaintingStyle.stroke;
        
      final innerGlowPaint = Paint()
        ..color = graphColor.withOpacity(0.4)
        ..strokeWidth = 3
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3)
        ..style = PaintingStyle.stroke;
      
      // Рисуем два слоя свечения для более глубокого эффекта
      canvas.drawPath(path, outerGlowPaint); // Внешнее свечение
      canvas.drawPath(path, innerGlowPaint); // Внутреннее свечение
      canvas.drawPath(path, paint); // Рисуем основную линию
      
      // Добавляем точки данных для улучшения восприятия
      final dotPaint = Paint()
        ..color = Colors.white
        ..style = PaintingStyle.fill;
      
      // Рисуем точки только на ключевых позициях для лучшего визуального эффекта
      for (int i = 0; i < speedData.length; i += 5) {
        if (i >= speedData.length) continue;
        double x = widthPerDataPoint * i;
        double y = size.height - (speedData[i] / maxSpeed * size.height).clamp(0, size.height);
        canvas.drawCircle(Offset(x, y), 2, dotPaint);
      }
    }
  }

  // Функция для рисования placeholder сетки
  void _drawPlaceholderGrid(Canvas canvas, Size size) {
    final placeholderPaint = Paint()
      ..color = graphPlaceholderColor.withOpacity(0.3)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    // Рисуем сетку с точечным пунктиром
    final dashPaint = Paint()
      ..color = graphPlaceholderColor.withOpacity(0.3)
      ..strokeWidth = 0.7
      ..style = PaintingStyle.stroke;

    // Рисуем горизонтальные линии с небольшим эффектом dash
    for (int i = 1; i <= 4; i++) {
      double y = size.height / 5 * i;
      _drawDashedLine(canvas, Offset(0, y), Offset(size.width, y), dashPaint);
    }

    // Добавляем вертикальные линии
    int verticalLines = 6;
    for (int i = 1; i < verticalLines; i++) {
      double x = size.width / verticalLines * i;
      _drawDashedLine(canvas, Offset(x, 0), Offset(x, size.height), dashPaint);
    }

    // Добавляем рамку вокруг графика
    final borderPaint = Paint()
      ..color = graphPlaceholderColor.withOpacity(0.5)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;
    
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, 0, size.width, size.height),
        const Radius.circular(4)
      ),
      borderPaint
    );
  }

  // Функция для рисования пунктирных линий
  void _drawDashedLine(Canvas canvas, Offset start, Offset end, Paint paint) {
    final Path path = Path()
      ..moveTo(start.dx, start.dy);

    const double dashWidth = 3;
    const double dashSpace = 4;
    
    final double dx = end.dx - start.dx;
    final double dy = end.dy - start.dy;
    final double distance = math.sqrt(dx * dx + dy * dy);
    final double steps = distance / (dashWidth + dashSpace);
    
    for (int i = 0; i < steps; i++) {
      path.lineTo(
        start.dx + dx * (i * (dashWidth + dashSpace)) / distance,
        start.dy + dy * (i * (dashWidth + dashSpace)) / distance,
      );
      
      path.lineTo(
        start.dx + dx * (i * (dashWidth + dashSpace) + dashWidth) / distance,
        start.dy + dy * (i * (dashWidth + dashSpace) + dashWidth) / distance,
      );
    }
    
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant SpeedGraphPainter oldDelegate) {
    return oldDelegate.speedData != speedData || oldDelegate.graphColor != graphColor;
  }
}