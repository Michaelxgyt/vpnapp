import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:flutter/services.dart'; // Import для MethodChannel

class TrafficScreen extends StatefulWidget {
  const TrafficScreen({Key? key}) : super(key: key);

  @override
  State<TrafficScreen> createState() => _TrafficScreenState();
}

class _TrafficScreenState extends State<TrafficScreen> {
  static const platform = MethodChannel('com.app.mrx/traffic');
  Map<String, dynamic> trafficData = {};
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _getTrafficData();
  }

  Future<void> _getTrafficData() async {
    setState(() {
      isLoading = true;
    });
    try {
      final result = await platform.invokeMethod('getTrafficData');
      setState(() {
        trafficData = Map<String, dynamic>.from(result);
      });
    } on PlatformException catch (e) {
      print("Failed to get traffic data: '${e.message}'.");
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Widget _buildTrafficSection(String title, String upload, String download) {
    return Container(
      padding: const EdgeInsets.all(16),
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Colors.grey[850],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.outfit(
              fontSize: 18,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Upload:',
                style: GoogleFonts.outfit(fontSize: 16, color: Colors.white70),
              ),
              Text(
                upload,
                style: GoogleFonts.outfit(fontSize: 16, color: Colors.blueAccent),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Download:',
                style: GoogleFonts.outfit(fontSize: 16, color: Colors.white70),
              ),
              Text(
                download,
                style: GoogleFonts.outfit(fontSize: 16, color: Colors.blueAccent),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          "Статистика трафика",
          style: GoogleFonts.outfit(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Get.back(),
        ),
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator(color: Colors.blueAccent))
          : Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (trafficData['monthly'] != null)
                _buildTrafficSection(
                  'За месяц',
                  '${formatBytes(trafficData['monthly']['upload'])}',
                  '${formatBytes(trafficData['monthly']['download'])}',
                ),
              if (trafficData['today'] != null)
                _buildTrafficSection(
                  'Сегодня',
                  '${formatBytes(trafficData['today']['upload'])}',
                  '${formatBytes(trafficData['today']['download'])}',
                ),
              if (trafficData['otherDays'] != null &&
                  (trafficData['otherDays'] as Map).isNotEmpty)
                Text(
                  'Остальные дни:',
                  style: GoogleFonts.outfit(
                    fontSize: 20,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ...(trafficData['otherDays'] as Map?)?.entries.map((entry) {
                return _buildTrafficSection(
                  DateFormat('yyyy-MM-dd').format(DateTime.parse(entry.key)),
                  '${formatBytes(entry.value['upload'])}',
                  '${formatBytes(entry.value['download'])}',
                );
              }).toList() ??
                  [],
            ],
          ),
        ),
      ),
    );
  }

  String formatBytes(int bytes, {int decimals = 2}) {
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    var i = ((bytes) / (1024)).floor();
    return '${(bytes / (1024)).toStringAsFixed(decimals)} ${suffixes[i]}';
  }
}