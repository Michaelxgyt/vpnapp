import 'package:flutter/material.dart';
import 'package:gamers_shield_vpn/screen/auth/login_screen.dart';
import 'package:gamers_shield_vpn/screen/home/home_screen.dart';
import 'package:gamers_shield_vpn/utils/app_constant.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    // clearSelection(); // Если необходимо очистить сохраненные данные
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(_animationController);
    _animationController.forward();
    _animationController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _checkToken();
      }
    });
  }



  Future<void> _checkToken() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    String? token = preferences.getString("token");

    if (token != null && token.isNotEmpty) {
      // Если токен существует, переходим на главный экран
      Get.offAll(() => const HomeScreen());
    } else {
      // Если токена нет, переходим на экран логина
      Get.offAll(() => const HomeScreen());
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  // Если вам нужно очистить сохраненные данные
  void clearSelection() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      prefs.remove('serverName');
      prefs.remove('config');
      prefs.remove('st');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900], // Темный фон
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Логотип приложения
              ClipOval(
                child: Image.asset(
                  'assets/images/app_logo.jpg',
                  width: 150,
                  height: 150,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'MRX VPN',
                textAlign: TextAlign.center,
                style: GoogleFonts.outfit(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
