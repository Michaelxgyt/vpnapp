import 'dart:convert';
import 'dart:io'; // For socket operations
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../controller/pro_server_controller.dart';
import '../../controller/server_controller.dart';
import '../../screen/home/home_screen.dart';

class LocationScreen extends StatefulWidget {
  const LocationScreen({Key? key}) : super(key: key);

  @override
  State<LocationScreen> createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  TextEditingController searchCtrl = TextEditingController();
  Map<String, int?> serverPingMap = {};
  List<Map<String, dynamic>> manualServers = [];
  bool isProUser = false;
  bool isPinging = false;
  bool _showOnboarding = false; // State to control onboarding overlay
  bool _isAutoUpdateEnabled = true; // Настройка для автоматического обновления
  bool _isFirstLoad = true; // Флаг для первой загрузки

  String? allowedProCollection;
  final ServerController serverController = Get.find<ServerController>();
  final ProServerController proServerController = Get.find<ProServerController>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this); // Регистрируем наблюдатель
    // Initialize controllers if not already initialized
    if (!Get.isRegistered<ServerController>()) {
      Get.put(ServerController());
    }
    if (!Get.isRegistered<ProServerController>()) {
      Get.put(ProServerController());
    }
    _loadAutoUpdateSetting();
    _checkUserProfile();
  }

  // Загрузка настройки автоматического обновления
  Future<void> _loadAutoUpdateSetting() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _isAutoUpdateEnabled = prefs.getBool('autoUpdateServers') ?? true;
    });
  }

  // Сохранение настройки автоматического обновления
  Future<void> _saveAutoUpdateSetting(bool value) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('autoUpdateServers', value);
    setState(() {
      _isAutoUpdateEnabled = value;
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this); // Отписываемся от наблюдателя
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    // Если приложение вернулось на передний план и автообновление включено
    if (state == AppLifecycleState.resumed && _isAutoUpdateEnabled) {
      // Обновляем данные
      _refreshServers(showSnackbar: false);
    }
  }

  // Check if onboarding has been shown before
  Future<void> _checkOnboardingStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool onboardingShown = prefs.getBool('manualServerOnboardingShown') ?? false;
    if (!onboardingShown) {
      setState(() {
        _showOnboarding = true; // Show onboarding if not shown before
      });
    }
  }

  // Set onboarding as shown
  Future<void> _setOnboardingShown() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('manualServerOnboardingShown', true);
    setState(() {
      _showOnboarding = false; // Hide onboarding after showing
    });
  }

  // Get the allowed Pro collection name and fetch servers
  Future<void> _initData() async {
    await _getAllowedProCollection(); // Get allowed pro collection first
    await _loadCachedServers();
    await _loadCachedPings();
    await _loadManualServers();

    // Если это первая загрузка и автообновление включено, обновляем серверы
    if (_isFirstLoad && _isAutoUpdateEnabled) {
      _isFirstLoad = false;
      // Небольшая задержка для улучшения пользовательского опыта
      Future.delayed(Duration(milliseconds: 500), () {
        _refreshServers(showSnackbar: false); // Тихое обновление
      });
    }
  }

  // Get the allowed Pro collection name
  Future<void> _getAllowedProCollection() async {
    allowedProCollection = await proServerController.getAllowedCollection();
    if (allowedProCollection != null) {
      await serverController.fetchProServers(allowedProCollection!); // Fetch pro servers here after getting collection
    }
  }

  // Load cached servers
  Future<void> _loadCachedServers() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Get the allowed collection name - already called in _initData

    // Use the collection name as cache key
    String proServersCacheKey =
        'proServers_${allowedProCollection ?? 'default'}';

    // Check if servers are saved
    String? cachedFreeServers = prefs.getString('freeServers');
    String? cachedProServers = prefs.getString(proServersCacheKey);

    if (cachedFreeServers != null) {
      // Restore free servers
      serverController.serverData.assignAll(
          List<Map<String, dynamic>>.from(jsonDecode(cachedFreeServers)));
      serverController.isLoading = false;
    } else {
      // Load from Firestore if not saved
      await serverController.fetchFreeServers(); // Загрузка только бесплатных
      // Save servers
      prefs.setString(
          'freeServers', jsonEncode(serverController.serverData));
    }

    if (cachedProServers != null) {
      // Restore Pro servers
      serverController.proServerData.assignAll( // Use serverController.proServerData
          List<Map<String, dynamic>>.from(jsonDecode(cachedProServers)));
      serverController.isProLoading = false; // Use serverController.isProLoading
    } else {
      // Load from Firestore if not saved
      if (allowedProCollection != null) {
        // Already fetched in _getAllowedProCollection
        // Save servers
        prefs.setString(
            proServersCacheKey, jsonEncode(serverController.proServerData)); // Save serverController.proServerData
      }
    }

    setState(() {});
  }

  // Load and save manual servers
  Future<void> _loadManualServers() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? cachedManualServers = prefs.getString('manualServers');
    if (cachedManualServers != null) {
      manualServers =
      List<Map<String, dynamic>>.from(jsonDecode(cachedManualServers));
      setState(() {});
    }
  }

  Future<void> _saveManualServers() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('manualServers', jsonEncode(manualServers));
  }

  // Load and save server pings
  Future<void> _loadCachedPings() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? cachedPings = prefs.getString('serverPings');
    if (cachedPings != null) {
      serverPingMap = Map<String, int?>.from(jsonDecode(cachedPings));
      setState(() {});
    }
  }

  Future<void> _savePingsToCache() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('serverPings', jsonEncode(serverPingMap));
  }

  // Refresh server list upon user request
  Future<void> _refreshServers({bool showSnackbar = true}) async {
    if (isPinging) return; // Prevent refresh if ping is in progress

    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Get the allowed collection name
    await _getAllowedProCollection();

    // Use the collection name as cache key
    String proServersCacheKey =
        'proServers_${allowedProCollection ?? 'default'}';

    try {
      // Update servers from Firestore
      await serverController.fetchFreeServers(); // Обновляем бесплатные
      if (allowedProCollection != null) {
        await serverController.fetchProServers(allowedProCollection!); // Обновляем Pro через ServerController
      }

      // Save updated servers
      prefs.setString(
          'freeServers', jsonEncode(serverController.serverData));
      if (allowedProCollection != null) {
        prefs.setString(
            proServersCacheKey, jsonEncode(serverController.proServerData)); // Сохраняем proServerData из ServerController
      }

      setState(() {});
      if (showSnackbar) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Серверы успешно обновлены.',
              style: TextStyle(color: Colors.white),
            ),
            backgroundColor: Colors.grey[850],
          ),
        );
      }
    } catch (e) {
      if (showSnackbar) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Не удалось обновить серверы: $e',
              style: TextStyle(color: Colors.white),
            ),
            backgroundColor: Colors.grey[850],
          ),
        );
      }
    }
  }

  // Check user profile
  Future<void> _checkUserProfile() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? studentId = prefs.getString("token");
    if (studentId != null) {
      try {
        QuerySnapshot snapshot = await FirebaseFirestore.instance
            .collection('users')
            .where('uid', isEqualTo: studentId)
            .get();
        if (snapshot.docs.isNotEmpty) {
          Map<String, dynamic> userProfile =
          snapshot.docs.first.data() as Map<String, dynamic>;
          setState(() {
            isProUser = userProfile['type'] == "Pro";
          });

          // After checking profile, initialize data loading
          await _initData();
        }
      } catch (e) {
        print('Ошибка при получении профиля пользователя: $e');
      }
    } else {
      // If not authenticated, load only free servers
      await _initData();
    }
  }

  // Extract IP address or domain from URL
  String? extractIpFromUrl(String url) {
    if (url.startsWith('vless://')) {
      return extractIpFromVless(url);
    } else if (url.startsWith('vmess://')) {
      return extractIpFromVmess(url);
    } else if (url.startsWith('ss://')) {
      return extractIpFromShadowsocks(url);
    }
    return null;
  }

  // Extract port from URL
  int? extractPortFromUrl(String url) {
    if (url.startsWith('vless://')) {
      return 443; // Default for VLESS
    } else if (url.startsWith('vmess://')) {
      return 443; // Default for Vmess
    } else if (url.startsWith('ss://')) {
      return extractPortFromShadowsocks(url);
    }
    return null;
  }

  // Methods to extract IP and port from various URL types
  String? extractIpFromVless(String vlessUrl) {
    try {
      Uri uri = Uri.parse(vlessUrl);
      return uri.host;
    } catch (e) {
      print('Ошибка при разборе VLESS URL: $e');
    }
    return null;
  }

  String? extractIpFromVmess(String vmessUrl) {
    try {
      String encodedData = vmessUrl.replaceFirst('vmess://', '');
      String decodedData = utf8.decode(base64.decode(encodedData));
      Map<String, dynamic> serverInfo = jsonDecode(decodedData);
      return serverInfo['add']; // 'add' is the server address field
    } catch (e) {
      print('Ошибка при разборе Vmess URL: $e');
    }
    return null;
  }

  String? extractIpFromShadowsocks(String ssUrl) {
    try {
      String base64Part = ssUrl.replaceFirst('ss://', '').split('@').last;
      Uri uri = Uri.parse('ss://$base64Part');
      return uri.host; // Extract IP or domain
    } catch (e) {
      print('Ошибка при разборе Shadowsocks URL: $e');
    }
    return null;
  }

  int? extractPortFromShadowsocks(String ssUrl) {
    try {
      String base64Part = ssUrl.replaceFirst('ss://', '').split('@').last;
      Uri uri = Uri.parse('ss://$base64Part');
      return uri.port; // Extract port
    } catch (e) {
      print('Ошибка при разборе Shadowsocks URL для порта: $e');
    }
    return null;
  }

  // Save server data
  Future<void> saveServerData(
      String serverName, String config, bool isPro) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('serverName', serverName);
    await prefs.setString('config', config);
    await prefs.setBool('isPro', isPro);
  }

  // Measure ping and update Firestore
  Future<void> measurePingForAllServers(
      List<Map<String, dynamic>> allServers) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? studentId = prefs.getString("token"); // Get user ID

    if (studentId == null) {
      print("User not authenticated. Skipping ping measurements.");
      return;
    }

    try {
      // Temporary map to store pings
      Map<String, int?> tempPingMap = {};

      // List of Futures for parallel ping execution
      List<Future<void>> pingFutures = allServers.map((server) async {
        String configUrl = server['config'] ?? '';
        String? serverIp = extractIpFromUrl(configUrl);
        int? port = extractPortFromUrl(configUrl) ?? 80;

        if (serverIp != null) {
          try {
            print("Измеряем пинг для: $serverIp на порту: $port");
            Stopwatch stopwatch = Stopwatch()..start();
            Socket socket = await Socket.connect(serverIp, port,
                timeout: Duration(seconds: 5));
            stopwatch.stop();
            socket.destroy();
            int ping = stopwatch.elapsedMilliseconds;
            tempPingMap[serverIp] = ping;
          } catch (e) {
            print("Не удалось измерить пинг для $serverIp: $e");
            tempPingMap[serverIp] = -1; // Set -1 if ping failed
          }
        } else {
          tempPingMap[serverIp ?? 'unknown'] = -1; // Set -1 if IP is null
        }
      }).toList();

      // Wait for all pings to complete
      await Future.wait(pingFutures);

      // Update the main ping map
      setState(() {
        serverPingMap = tempPingMap;
      });

      // Save pings to cache
      await _savePingsToCache();

      // Update Firestore in one call
      DocumentReference userDoc =
      FirebaseFirestore.instance.collection('users').doc(studentId);
      await userDoc.set({'pings': jsonEncode(serverPingMap)},
          SetOptions(merge: true));

      print("Пинги успешно обновлены в Firestore.");
    } catch (e) {
      print("Ошибка при обновлении пингов: $e");
    }
  }

  void _addManualServerDialog() {
    String serverName = '';
    String serverConfig = '';
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: Colors.grey[850],
          title: Text('Добавить ручной сервер', style: TextStyle(color: Colors.white)),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                TextField(
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'Название сервера',
                    labelStyle: TextStyle(color: Colors.white70),
                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70)),
                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.blueAccent)),
                  ),
                  onChanged: (value) {
                    serverName = value;
                  },
                ),
                TextField(
                  style: TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    labelText: 'V2Ray Config URL',
                    labelStyle: TextStyle(color: Colors.white70),
                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white70)),
                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.blueAccent)),
                  ),
                  onChanged: (value) {
                    serverConfig = value;
                  },
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Отмена', style: TextStyle(color: Colors.white)),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('Добавить', style: TextStyle(color: Colors.blueAccent)),
              onPressed: () {
                if (serverName.isNotEmpty && serverConfig.isNotEmpty) {
                  bool isFirstManualServer = manualServers.isEmpty; // Check if it's the first manual server
                  setState(() {
                    manualServers.add({
                      'serverName': serverName,
                      'config': serverConfig,
                      'isManual': true, // Flag to identify manual servers
                    });
                    _saveManualServers();
                  });
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Сервер добавлен', style: TextStyle(color: Colors.white)),
                      backgroundColor: Colors.grey[850],
                    ),
                  );
                  if (isFirstManualServer) {
                    _checkOnboardingStatus(); // Show onboarding after adding the first server
                  }

                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Заполните все поля', style: TextStyle(color: Colors.white)),
                      backgroundColor: Colors.grey[850],
                    ),
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> freeServers = [...serverController.serverData.cast<Map<String, dynamic>>().toList(), ...manualServers];
    List<Map<String, dynamic>> proServers = serverController.proServerData.cast<Map<String, dynamic>>().toList();


    return Stack( // Wrap Scaffold in Stack to overlay onboarding
      children: [
        Scaffold(
          backgroundColor: Colors.grey[900],
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            automaticallyImplyLeading: false,
            leading: IconButton(
              onPressed: () {
                Get.back();
              },
              icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
            ),
            title: Text(
              "Выбор сервера",
              style: GoogleFonts.outfit(color: Colors.white, fontSize: 24),
            ),
            actions: [
              IconButton(
                icon: Icon(Icons.add, color: Colors.white), // Button to add manual server
                onPressed: _addManualServerDialog,
              ),
              // Добавляем переключатель автоматического обновления
              IconButton(
                icon: Icon(
                  _isAutoUpdateEnabled
                      ? Icons.update
                      : Icons.update_disabled,
                  color: _isAutoUpdateEnabled ? Colors.green : Colors.white,
                ),
                onPressed: () {
                  _saveAutoUpdateSetting(!_isAutoUpdateEnabled);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        _isAutoUpdateEnabled
                            ? 'Автоматическое обновление отключено'
                            : 'Автоматическое обновление включено',
                        style: TextStyle(color: Colors.white),
                      ),
                      backgroundColor: Colors.grey[850],
                    ),
                  );
                },
                tooltip: _isAutoUpdateEnabled
                    ? 'Автоматическое обновление включено'
                    : 'Автоматическое обновление отключено',
              ),
              IconButton(
                icon: Icon(Icons.refresh, color: Colors.white),
                onPressed: () => _refreshServers(showSnackbar: true),
              ),
            ],
          ),
          resizeToAvoidBottomInset: false,
          body: serverController.isLoading || proServerController.isLoading.value
              ? Center(child: CircularProgressIndicator())
              : Padding(
            padding: const EdgeInsets.all(24.0),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Бесплатные серверы",
                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  if (manualServers.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: Text(
                        "Для удаления сервера смахните влево.",
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: freeServers.length,
                    itemBuilder: (context, index) {
                      final server = freeServers[index];
                      String configUrl = server["config"] ?? '';
                      String? serverIp = extractIpFromUrl(configUrl);
                      int? pingValue;
                      Color pingColor = Colors.green;

                      if (serverIp != null && serverPingMap.containsKey(serverIp)) {
                        pingValue = serverPingMap[serverIp];
                        if (pingValue == -1 || pingValue == null) {
                          pingColor = Colors.red;
                          pingValue = -1;
                        } else {
                          pingColor = Colors.green;
                        }
                      }


                      return Dismissible(
                        key: Key(server["config"]),
                        direction: server['isManual'] == true ? DismissDirection.endToStart : DismissDirection.none,
                        confirmDismiss: (direction) async {
                          if (server['isManual'] == true) {
                            return await showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  backgroundColor: Colors.grey[850],
                                  title: Text("Удалить сервер?", style: TextStyle(color: Colors.white)),
                                  content: Text("Вы уверены, что хотите удалить ${server["serverName"]}?", style: TextStyle(color: Colors.white70)),
                                  actions: <Widget>[
                                    TextButton(
                                      onPressed: () => Navigator.of(context).pop(false),
                                      child: Text("Отмена", style: TextStyle(color: Colors.white)),
                                    ),
                                    TextButton(
                                      onPressed: () => Navigator.of(context).pop(true),
                                      child: Text("Удалить", style: TextStyle(color: Colors.redAccent)),
                                    ),
                                  ],
                                );
                              },
                            );
                          }
                          return false;
                        },
                        onDismissed: (direction) {
                          if (server['isManual'] == true) {
                            setState(() {
                              manualServers.removeWhere((item) => item["config"] == server["config"]);
                              _saveManualServers();
                            });
                            ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                    content: Text("${server["serverName"]} удален", style: TextStyle(color: Colors.white)),
                                    backgroundColor: Colors.grey[850])
                            );
                          }
                        },
                        background: Container(
                          color: Colors.redAccent,
                          alignment: Alignment.centerRight,
                          padding: EdgeInsets.only(right: 20.0),
                          child: Icon(Icons.delete, color: Colors.white),
                        ),
                        child: Card(
                          color: Colors.grey[850],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: ListTile(
                            leading: Icon(server['isManual'] == true ? Icons.edit_location_alt : Icons.public, color: Colors.white),
                            title: Text(
                              "${server["serverName"]}",
                              style: TextStyle(color: Colors.white),
                            ),
                            subtitle: pingValue != null
                                ? RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: "Пинг: ",
                                    style: TextStyle(color: Colors.white70),
                                  ),
                                  TextSpan(
                                    text: "$pingValue ms",
                                    style: TextStyle(color: pingColor),
                                  ),
                                ],
                              ),
                            )
                                : Text(
                              "Пинг: -",
                              style: TextStyle(color: Colors.white70),
                            ),
                            onTap: () async {
                              SharedPreferences prefs = await SharedPreferences.getInstance();
                              await saveServerData(
                                server["serverName"],
                                server["config"],
                                false, // Manual servers are always free
                              );
                              if (prefs.getString("serverName") != null &&
                                  prefs.getString("config") != null) {
                                Get.offAll(() => HomeScreen());
                              }
                            },
                          ),
                        ),
                      );
                    },
                  ),
                  SizedBox(height: 20),

                  if (isProUser)
                    Obx(() => proServerController.isLoading.value
                        ? Center(
                      child: Column(
                        children: [
                          CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.blueAccent),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Загрузка Pro серверов...",
                            style: TextStyle(color: Colors.white70),
                          ),
                        ],
                      ),
                    )
                        : (proServers.isNotEmpty ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Pro серверы",
                          style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 10),
                        ListView.builder(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: proServers.length,
                          itemBuilder: (context, index) {
                            final server = proServers[index];
                            String configUrl = server["config"] ?? '';
                            String? serverIp = extractIpFromUrl(configUrl);
                            int? pingValue;
                            Color pingColor = Colors.green;

                            if (serverIp != null && serverPingMap.containsKey(serverIp)) {
                              pingValue = serverPingMap[serverIp];
                              if (pingValue == -1 || pingValue == null) {
                                pingColor = Colors.red;
                                pingValue = -1;
                              } else {
                                pingColor = Colors.green;
                              }
                            }

                            return Card(
                              color: Colors.grey[850],
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: ListTile(
                                leading: Icon(Icons.security, color: Colors.white),
                                title: Text(
                                  "${server["serverName"]}",
                                  style: TextStyle(color: Colors.white),
                                ),
                                subtitle: pingValue != null
                                    ? RichText(
                                  text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Пинг: ",
                                        style: TextStyle(color: Colors.white70),
                                      ),
                                      TextSpan(
                                        text: "$pingValue ms",
                                        style: TextStyle(color: pingColor),
                                      ),
                                    ],
                                  ),
                                )
                                    : Text(
                                  "Пинг: -",
                                  style: TextStyle(color: Colors.white70),
                                ),
                                onTap: () async {
                                  SharedPreferences prefs = await SharedPreferences.getInstance();
                                  await saveServerData(
                                    server["serverName"],
                                    server["config"],
                                    true,
                                  );
                                  if (prefs.getString("serverName") != null &&
                                      prefs.getString("config") != null) {
                                    Get.offAll(() => HomeScreen());
                                  }
                                },
                              ),
                            );
                          },
                        ),
                      ],
                    ) : SizedBox.shrink()
                    ),
                    ),


                  if (!isProUser)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 28),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            "Вы не являетесь премиум-пользователем. Pro серверы доступны только для премиум-пользователей.",
                            style: TextStyle(color: Colors.white),
                            textAlign: TextAlign.center,
                          ),
                          SizedBox(height: 16),
                          ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blueAccent,
                              minimumSize: Size(double.infinity, 50),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            onPressed: () async {
                              String url = "https://t.me/ShadowsockTM";
                              if (kDebugMode) {
                                print("launchingUrl: $url");
                              }
                              if (await canLaunch(url)) {
                                await launch(url);
                              }
                            },
                            icon: Icon(Icons.telegram, color: Colors.white),
                            label: Text(
                              "Присоединиться к Telegram",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          floatingActionButton: FloatingActionButton(
            backgroundColor:
            isPinging ? Colors.grey : Colors.blueAccent,
            child: Icon(Icons.flash_on, color: Colors.white),
            onPressed: isPinging
                ? null
                : () async {
              setState(() {
                isPinging = true;
              });

              List<Map<String, dynamic>> combinedServers = [
                ...serverController.serverData,
                ...serverController.proServerData,
                ...manualServers,
              ];

              await measurePingForAllServers(combinedServers);

              setState(() {
                isPinging = false;
              });
            },
          ),
        ),
        if (_showOnboarding) // Show onboarding overlay if _showOnboarding is true
          ManualServerOnboardingOverlay(onDismiss: _setOnboardingShown),
      ],
    );
  }
}


class ManualServerOnboardingOverlay extends StatelessWidget {
  final VoidCallback onDismiss;

  const ManualServerOnboardingOverlay({Key? key, required this.onDismiss}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.7), // Slightly adjusted opacity for background
        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 40),
        child: Center( // Center the Card in the middle of the screen
          child: Card( // Using Card for a styled container
            elevation: 8, // Add elevation for a subtle shadow
            color: Colors.grey[850], // Darker card background
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), // Rounded corners for the card
            child: Padding(
              padding: const EdgeInsets.all(24.0), // Padding inside the card
              child: Column(
                mainAxisSize: MainAxisSize.min, // Make column fit its content
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Ручные серверы добавлены!",
                    style: GoogleFonts.outfit( // Using Outfit font
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 24),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.swipe_left, color: Colors.redAccent, size: 36), // Slightly larger icon
                            SizedBox(width: 16),
                            Expanded(
                              child: Text(
                                "Смахните влево чтобы удалить сервер",
                                style: GoogleFonts.outfit( // Using Outfit font
                                  color: Colors.white70, // Slightly softer white
                                  fontSize: 18,
                                ),
                                textAlign: TextAlign.start,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 32),
                  ElevatedButton(
                    onPressed: onDismiss,
                    child: Text(
                      "Понятно",
                      style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.bold), // Outfit font for button text
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueAccent,
                      padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12), // More padding for button
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), // Rounded button corners
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}