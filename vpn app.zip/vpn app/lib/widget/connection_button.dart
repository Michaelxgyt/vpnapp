import 'package:flutter/material.dart';

class ConnectionButton extends StatelessWidget {
  final bool isLoading;
  final bool isConnected;
  final VoidCallback onPressed;

  const ConnectionButton({
    Key? key,
    required this.isLoading,
    required this.isConnected,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double size = MediaQuery.of(context).size.width * 0.35;
    return GestureDetector(
      onTap: isLoading ? null : onPressed,
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  isConnected ? Colors.greenAccent.shade700 : Colors.blueAccent.shade700,
                  isConnected ? Colors.greenAccent.shade400 : Colors.blueAccent.shade400,
                  Colors.transparent,
                ],
                stops: const [0.3, 0.7, 1.0],
              ),
            ),
          ),
          Container(
            width: size * 0.85,
            height: size * 0.85,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF262A4D),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 10,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Center(
              child: isLoading
                  ? const CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Colors.white))
                  : Icon(
                Icons.power_settings_new,
                color: isConnected ? Colors.white : Colors.white70,
                size: size * 0.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
}