// lib/background/background_tasks.dart
/*
import 'dart:async';
import 'package:flutter/widgets.dart'; // Необходим для WidgetsFlutterBinding
import 'package:shared_preferences/shared_preferences.dart';
import 'package:firebase_core/firebase_core.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_v2ray/flutter_v2ray.dart';
import 'package:workmanager/workmanager.dart';
import '../firebase_options.dart';
import 'background_task_constants.dart'; // Импорт констант

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    WidgetsFlutterBinding.ensureInitialized();

    print("Фоновая задача: Запуск задачи $task");

    try {
      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );
      print("Фоновая задача: Firebase инициализирован.");
    } catch (e) {
      print("Фоновая задача: Ошибка инициализации Firebase: $e");
      return Future.value(false);
    }

    switch (task) {
      case accountCheckTask:
        print("Фоновая задача: Запуск performPeriodicAccountCheck");
        try {
          await performPeriodicAccountCheck();
        } catch (e) {
          print("Фоновая задача: Ошибка при выполнении проверки аккаунта: $e");
          return Future.value(false);
        }
        break;

      case trafficUpdateTask:
        print("Фоновая задача: Запуск performTrafficUpdate");
        try {
          await performTrafficUpdate();
        } catch (e) {
          print("Фоновая задача: Ошибка при обновлении трафика: $e");
          return Future.value(false);
        }
        break;

      default:
        print("Фоновая задача: Неизвестная задача $task");
        return Future.value(false);
    }

    print("Фоновая задача: Завершение задачи $task");
    return Future.value(true);
  });
}

@pragma('vm:entry-point')
Future<void> performPeriodicAccountCheck() async {
  try {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString("token");

    if (userId != null) {
      print("Фоновая задача: Найден ID пользователя: $userId");

      var userProfile = await fetchUserProfile(userId);

      if (userProfile != null && userProfile['type'] != null) {
        print("Фоновая задача: Тип пользователя: ${userProfile['type']}");
        bool isPro = userProfile['type'] == "Pro";

        bool wasPro = prefs.getBool('isPro') ?? false;

        if (wasPro && !isPro) {
          print("Фоновая задача: Пользователь больше не Pro. Выполнение необходимых действий.");

          FlutterV2ray flutterV2ray = FlutterV2ray(
            onStatusChanged: (_) {},
          );

          try {
            await flutterV2ray.stopV2Ray();
            print("V2Ray успешно остановлен в фоне.");
          } catch (e) {
            print("Фоновая задача: Ошибка при остановке V2Ray в фоне: $e");
          }

          // await updateUserStatus(userId, "DISCONNECTED");

          bool configCleared = await clearServerData(prefs, flutterV2ray);

          if (configCleared) {
            print("Фоновая задача: Данные о сервере и конфигурации успешно очищены.");
          } else {
            print("Фоновая задача: Ошибка при очистке данных о сервере и конфигурации.");
          }
        } else if (isPro) {
          print("Фоновая задача: Пользователь имеет статус Pro. Инициализация V2Ray.");

          FlutterV2ray flutterV2ray = FlutterV2ray(
            onStatusChanged: (_) {},
          );

          try {
            await flutterV2ray.initializeV2Ray();
            print("Фоновая задача: V2Ray инициализирован для Pro пользователя.");
          } catch (e) {
            print("Фоновая задача: Ошибка инициализации V2Ray: $e");
          }

          // Обновляем флаг isPro в SharedPreferences
          await prefs.setBool('isPro', true);
        } else {
          print("Фоновая задача: Пользователь не Pro и не было изменений статуса.");
        }
      } else {
        print("Фоновая задача: Профиль пользователя не найден или тип не определен. Обновление статуса.");
        // await updateUserStatus(userId, "DISCONNECTED");
      }
    } else {
      print("Фоновая задача: Токен пользователя не найден.");
    }
  } catch (e) {
    print("Фоновая задача: Ошибка при проверке аккаунта: $e");
  }
}

@pragma('vm:entry-point')
Future<void> performTrafficUpdate() async {
  try {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    double? currentUpload = prefs.getDouble("currentUpload");
    double? currentDownload = prefs.getDouble("currentDownload");

    print("Фоновая задача: currentUpload=$currentUpload, currentDownload=$currentDownload");

    if (currentUpload == null || currentDownload == null) {
      print("Фоновая задача: Текущие данные трафика не найдены.");
      return;
    }

    String? userId = prefs.getString("token");
    if (userId == null) {
      print("Фоновая задача: Ошибка: Токен пользователя не найден.");
      return;
    }

    double lastUpload = prefs.getDouble('lastUpload') ?? 0.0;
    double lastDownload = prefs.getDouble('lastDownload') ?? 0.0;

    double uploadDelta = currentUpload - lastUpload;
    double downloadDelta = currentDownload - lastDownload;

    if (uploadDelta < 0) uploadDelta = 0;
    if (downloadDelta < 0) downloadDelta = 0;

    await prefs.setDouble('lastUpload', currentUpload);
    await prefs.setDouble('lastDownload', currentDownload);

    String timestamp = DateTime.now().toIso8601String();
    String newData = "$timestamp|${uploadDelta.toStringAsFixed(2)}|${downloadDelta.toStringAsFixed(2)}";

    // await FirebaseFirestore.instance
    //     .collection('users')
    //     .doc(userId)
    //     .update({'data': FieldValue.arrayUnion([newData])});

    print("Фоновая задача: Данные трафика обновлены: $newData");
  } catch (e) {
    print("Фоновая задача: Ошибка при обновлении данных трафика: $e");
  }
}
@pragma('vm:entry-point')
Future<bool> clearServerData(SharedPreferences prefs, FlutterV2ray flutterV2ray) async {
  try {
    // Останавливаем V2Ray, если он еще запущен
    await flutterV2ray.stopV2Ray();

    // Очищаем все связанные данные из SharedPreferences
    await prefs.setBool('isPro', false);
    await prefs.remove('serverName');
    await prefs.remove('config');

    // Если FlutterV2ray предоставляет метод для сброса конфигурации, используем его
    // Например:
    // await flutterV2ray.resetConfiguration();

    // В зависимости от реализации FlutterV2ray, может потребоваться дополнительная очистка
    // Например, удаление файлов конфигурации, если они хранятся на диске

    return true;
  } catch (e) {
    print("Фоновая задача: Ошибка при очистке данных о сервере: $e");
    return false;
  }
}

@pragma('vm:entry-point')
Future<Map<String, dynamic>?> fetchUserProfile(String id) async {
  try {
    print("Фоновая задача: Получение профиля пользователя с ID: $id");
    // QuerySnapshot snapshot = await FirebaseFirestore.instance
    //     .collection('users')
    //     .where('uid', isEqualTo: id)
    //     .get();
    // if (snapshot.docs.isNotEmpty) {
    //   print("Фоновая задача: Профиль пользователя найден.");
    //   return snapshot.docs.first.data() as Map<String, dynamic>;
    // } else {
    //   print("Фоновая задача: Профиль пользователя не найден.");
    // }
  } catch (e) {
    print("Фоновая задача: Ошибка при получении профиля пользователя: $e");
  }
  return null;
}

@pragma('vm:entry-point')
Future<void> updateUserStatus(String userId, String status) async {
  try {
    String newStatus = status == "CONNECTED" ? "active" : "inactive";
    // await FirebaseFirestore.instance.collection('users').doc(userId).update({'status': newStatus});
    print("Фоновая задача: Статус пользователя обновлён: $newStatus");
  } catch (e) {
    print("Фоновая задача: Ошибка при обновлении статуса пользователя: $e");
  }
}
*/