// lib/background/background_task_constants.dart

@pragma('vm:entry-point')
const String trafficUpdateTask = "trafficUpdateTask";
const String accountCheckTask = "accountCheckTask";

