import 'package:flutter/material.dart';

class AppColors{
  static Color appBgColor = Color(0xff292A4C);
  static Color appButtonColor = Color(0xff494968);
}