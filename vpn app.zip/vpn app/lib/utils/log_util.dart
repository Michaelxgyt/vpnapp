// log_util.dart
import 'package:flutter/foundation.dart';

void appLog(String message, {String level = "INFO"}) {
  if (kDebugMode) {
    final logMessage = "[${DateTime.now().toIso8601String()}] [$level] $message";
    print(logMessage);
  }
}
