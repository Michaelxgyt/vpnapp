package com.app.mrx

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.view.ContextThemeWrapper
import android.Manifest
import androidx.core.app.ActivityCompat
import com.google.firebase.FirebaseApp
import com.github.blueboytm.flutter_v2ray.v2ray.core.V2rayCoreManager
import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

    private val tag = "MainActivity"
    private val BATTERY_OPTIMIZATION_REQUEST_CODE = 123
    private var dialogShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Log.d(tag, "onCreate вызван")

        // Инициализация Firebase в нативной части
        if (FirebaseApp.getApps(this).isEmpty()) {
            FirebaseApp.initializeApp(this)
        }

        // Инициализация V2rayCoreManager
        val v2rayManager = V2rayCoreManager.getInstance()

        // Запуск UnifiedNotifyService при создании MainActivity
        Intent(this, UnifiedNotifyService::class.java).also { intent ->
            startService(intent)
        }

        // Используем Handler с задержкой для показа диалога
        // и проверки фактического состояния разрешения
        Handler(Looper.getMainLooper()).postDelayed({
            checkBatteryOptimizationStatus()
        }, 2000) // задержка в 2 секунды
    }

    // Основной метод проверки статуса оптимизации батареи
    private fun checkBatteryOptimizationStatus() {
        Log.d(tag, "checkBatteryOptimizationStatus вызван")

        // Избегаем повторного показа в рамках одной сессии
        if (dialogShown) {
            Log.d(tag, "Диалог уже был показан в этой сессии, пропускаем")
            return
        }

        // Проверяем только если API уровень подходящий
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            val packageName = packageName

            // КЛЮЧЕВАЯ ПРОВЕРКА: фактически предоставлено ли исключение из оптимизации
            val isIgnoringBatteryOptimizations = powerManager.isIgnoringBatteryOptimizations(packageName)
            Log.d(tag, "Статус игнорирования оптимизации батареи: $isIgnoringBatteryOptimizations")

            // Если оптимизация уже отключена, ничего не делаем
            if (isIgnoringBatteryOptimizations) {
                Log.d(tag, "Оптимизация батареи уже отключена")
                return
            }

            // Если оптимизация НЕ отключена, показываем диалог
            showDarkStyledDialog()
        } else {
            Log.d(tag, "API Level ниже M (23), пропускаем проверку оптимизации батареи")
        }
    }

    // Темный диалог в стиле приложения
    private fun showDarkStyledDialog() {
        Log.d(tag, "showDarkStyledDialog вызван")

        try {
            // Устанавливаем флаг, что диалог был показан в этой сессии
            dialogShown = true

            // Создаем контекст с темным стилем
            val darkThemeContext = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)

            val builder = AlertDialog.Builder(darkThemeContext)

            builder.setTitle("Разрешение приложению")
            builder.setMessage("Для стабильной работы уведомлений о VPN-соединении, разрешите приложению работать в фоновом режиме")

            // Указываем типы явно для лямбда-выражений
            builder.setPositiveButton("Разрешить") { dialog, which ->
                Log.d(tag, "Пользователь нажал 'Разрешить'")
                requestBatteryOptimizationExemption()
            }

            // Просто закрываем диалог без сохранения флага
            builder.setNegativeButton("Не сейчас") { dialog, which ->
                Log.d(tag, "Пользователь нажал 'Не сейчас'")
                dialog.dismiss()
            }

            builder.setCancelable(true)

            // Показываем диалог на главном потоке
            runOnUiThread {
                try {
                    val dialog = builder.create()
                    dialog.show()

                    // Устанавливаем цвет кнопок при необходимости
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.let { positiveButton ->
                        positiveButton.setTextColor(android.graphics.Color.parseColor("#2979FF")) // BlueAccent
                    }

                    Log.d(tag, "Диалог успешно показан")
                } catch (e: Exception) {
                    Log.e(tag, "Ошибка при показе диалога: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "Ошибка при подготовке диалога: ${e.message}")
        }
    }

    // Запрос исключения из оптимизации батареи
    private fun requestBatteryOptimizationExemption() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val powerManager = getSystemService(POWER_SERVICE) as PowerManager
            val packageName = packageName
            if (!powerManager.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent()
                intent.action = Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            }
        }
    }

    // Метод обработки результата для SDK < 30
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        Log.d(tag, "onActivityResult вызван: requestCode=$requestCode, resultCode=$resultCode")

        if (requestCode == BATTERY_OPTIMIZATION_REQUEST_CODE) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                val powerManager = getSystemService(POWER_SERVICE) as PowerManager

                // ВАЖНО: ещё раз проверяем, действительно ли разрешение получено
                val isIgnoring = powerManager.isIgnoringBatteryOptimizations(packageName)
                Log.d(tag, "Проверка разрешения: isIgnoringBatteryOptimizations=$isIgnoring")
                
                // Если разрешение получено, перезапускаем сервис уведомлений для обеспечения стабильной работы
                if (isIgnoring) {
                    restartUnifiedNotifyService()
                }
            }
        }
    }

    // Проверка в onResume для случаев, когда пользователь вернулся в приложение
    override fun onResume() {
        super.onResume()
        Log.d(tag, "onResume вызван")
        
        // Проверяем и запрашиваем разрешение на уведомления для Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                Log.d(tag, "Запрашиваем разрешение на уведомления для Android 13+")
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }
        
        // Проверяем, работает ли V2Ray core и наш сервис уведомлений
        val v2rayManager = V2rayCoreManager.getInstance()
        val isRunning = v2rayManager.isV2rayCoreRunning()
        Log.d(tag, "onResume: V2Ray работает: $isRunning")
        
        // Всегда перезапускаем сервис уведомлений - он сам определит,
        // нужно ли показывать уведомление на основе состояния V2Ray
        restartUnifiedNotifyService()
    }
    
    // Метод перезапуска сервиса уведомлений
    private fun restartUnifiedNotifyService() {
        try {
            // Это обеспечит, что сервис уведомлений будет запущен или перезапущен
            val intent = Intent(this, UnifiedNotifyService::class.java)
            // Добавляем флаг для распознавания перезапуска из MainActivity
            intent.putExtra("RESTART_FROM_ACTIVITY", true)
            
            Log.d(tag, "Перезапуск UnifiedNotifyService из MainActivity")
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Log.d(tag, "Запускаем как foreground service (Android 8.0+)")
                startForegroundService(intent)
            } else {
                Log.d(tag, "Запускаем как обычный service")
                startService(intent)
            }
            Log.d(tag, "UnifiedNotifyService перезапущен из MainActivity")
        } catch (e: Exception) {
            Log.e(tag, "Ошибка при перезапуске UnifiedNotifyService: ${e.message}", e)
        }
    }
}