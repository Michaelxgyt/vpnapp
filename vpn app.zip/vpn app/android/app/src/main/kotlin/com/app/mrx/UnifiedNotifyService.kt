package com.app.mrx

import kotlinx.coroutines.isActive
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.net.Uri
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.github.blueboytm.flutter_v2ray.v2ray.V2rayController
import com.github.blueboytm.flutter_v2ray.v2ray.core.V2rayCoreManager
import com.github.blueboytm.flutter_v2ray.v2ray.services.V2rayProxyOnlyService
import com.github.blueboytm.flutter_v2ray.v2ray.services.V2rayVPNService
import com.github.blueboytm.flutter_v2ray.v2ray.utils.AppConfigs
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max

class UnifiedNotifyService : Service() {

    // Use the same notification ID as V2rayCoreManager (which is 1)
    private val notificationId = 1
    private var lastUploadBytes: Long = 0
    private var lastDownloadBytes: Long = 0
    private var previousUploadBytes: Long = 0
    private var previousDownloadBytes: Long = 0
    private var trafficUpdateJob: Job? = null
    private val coroutineScope = CoroutineScope(Dispatchers.IO)
    private val tag = "UnifiedNotifyService"
    private var isVpnConnected = false
    private var isTrafficUpdatesRunning = false
    private var isAccountCheckingRunning = false
    private var isSubscriptionExpiryCheckingRunning = false // Новая переменная для проверки истечения подписки
    private var currentUploadSpeed: Long = 0
    private var currentDownloadSpeed: Long = 0
    private var connectionDuration: String = "00:00:00"
    private var wakeLock: PowerManager.WakeLock? = null

    private val trafficUpdateInterval = TimeUnit.MINUTES.toMillis(20)
    private val accountCheckInterval = TimeUnit.MINUTES.toMillis(10)
    private val subscriptionCheckInterval = TimeUnit.HOURS.toMillis(6) // Проверка подписки каждые 6 часов

    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var notificationBuilder: NotificationCompat.Builder

    private val connectionInfoReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent?.let {
                val stateObject = it.extras?.get("STATE")
                val stateString = when (stateObject) {
                    is Enum<*> -> stateObject.name
                    is String -> stateObject
                    else -> null
                }

                //Log.d(tag, "connectionInfoReceiver - Получено состояние: $stateString, isVpnConnected: $isVpnConnected")

                // Получение данных о скорости и времени соединения
                val downloadSpeed = it.getLongExtra("DOWNLOAD_SPEED", 0)
                val uploadSpeed = it.getLongExtra("UPLOAD_SPEED", 0)
                val duration = it.getStringExtra("DURATION") ?: "00:00:00"

                currentDownloadSpeed = downloadSpeed
                currentUploadSpeed = uploadSpeed
                connectionDuration = duration

                when (stateString) {
                    "V2RAY_CONNECTED" -> {
                       // Log.d(tag, "connectionInfoReceiver - Получено состояние V2RAY_CONNECTED")
                        if (!isVpnConnected) {
                            isVpnConnected = true
                            Log.d(tag, "connectionInfoReceiver - VPN Подключен")
                            ensureForegroundService() // Используем новый метод здесь вместо startForegroundServiceWithNotification()
                            startPeriodicTasks()
                            updateUserStatus("CONNECTED")

                            // Синхронизируем дату окончания подписки при подключении
                            CoroutineScope(Dispatchers.IO).launch {
                                fetchAndSaveExpiryDate()
                            }
                        } else {
                            // Если уже подключен, просто обновляем информацию о трафике
                            updateNotificationWithTraffic()
                        }
                    }
                    "V2RAY_DISCONNECTED" -> {
                        if (isVpnConnected) {
                            isVpnConnected = false
                            Log.d(tag, "connectionInfoReceiver - VPN Отключен")

                            runBlocking {
                                updateUserStatus("DISCONNECTED")
                            }
                            updateNotification("VPN Соединение Отключено", "VPN неактивно")
                            Log.d(tag, "connectionInfoReceiver - Статус пользователя обновлен, останавливаем все задачи и foreground service")
                            stopPeriodicTasks()
                            stopForegroundServiceSafely()
                        } else {
                            Log.d(tag, "connectionInfoReceiver - VPN уже отключен, игнорируем.")
                        }
                    }
                    else -> {
                        // Если статус изменился или не определен, но VPN подключен - обновляем информацию о трафике
                        if (isVpnConnected) {
                            updateNotificationWithTraffic()
                        }
                        Log.w(tag, "connectionInfoReceiver - Неизвестное состояние: $stateString")
                    }
                }

                val currentDownloadBytes = it.getLongExtra("DOWNLOAD_TRAFFIC", 0)
                val currentUploadBytes = it.getLongExtra("UPLOAD_TRAFFIC", 0)
                updateTrafficData(currentUploadBytes, currentDownloadBytes)
            } ?: Log.w(tag, "connectionInfoReceiver - Intent равен null")
        }
    }

    // Новый метод для обеспечения работы сервиса на переднем плане
    private fun ensureForegroundService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Для Android 8.0+, нужно перезапускать foreground service каждый раз
            try {
                Log.d(tag, "ensureForegroundService - Проверка, что сервис находится на переднем плане")
                stopForeground(true)
                startForegroundServiceWithNotification()
            } catch (e: Exception) {
                Log.e(tag, "ensureForegroundService - Ошибка: ${e.message}", e)
            }
        } else {
            // Для более старых версий Android, просто обновляем уведомление
            updateNotificationWithTraffic()
        }
    }

    // Метод для форматирования скорости в читаемый вид (Кб/с или Мб/с)
    private fun formatSpeed(bytes: Long): String {
        return when {
            bytes < 1024 -> "$bytes Б/с"
            bytes < 1024 * 1024 -> String.format("%.1f Кб/с", bytes / 1024.0)
            else -> String.format("%.2f Мб/с", bytes / (1024.0 * 1024.0))
        }
    }

    // Обновляем уведомление с информацией о скорости и времени
    private fun updateNotificationWithTraffic() {
        val downloadSpeedFormatted = formatSpeed(currentDownloadSpeed)
        val uploadSpeedFormatted = formatSpeed(currentUploadSpeed)

        // Заголовок с основной информацией о скорости
        val title = "▼$downloadSpeedFormatted ▲$uploadSpeedFormatted"

        // Дополнительная информация о времени подключения
        val text = "Время: $connectionDuration"

        updateNotification(title, text)
    }

    private fun startPeriodicTasks() {
        Log.d(tag, "startPeriodicTasks - Запуск периодических задач")

        val isProUser = getProStatus()
        if (!isProUser) {
            Log.d(tag, "startPeriodicTasks - Аккаунт не Pro, периодические задачи не запускаются.")
            return
        }

        startTrafficUpdates()
        startAccountChecking()
        startSubscriptionExpiryChecking() // Запускаем проверку истечения подписки
    }

    private fun stopPeriodicTasks() {
        stopTrafficUpdates()
        stopAccountChecking()
        stopSubscriptionExpiryChecking() // Останавливаем проверку истечения подписки
    }

    // Новый метод: Запуск проверки истечения срока подписки
    private fun startSubscriptionExpiryChecking() {
        Log.d(tag, "startSubscriptionExpiryChecking - Запрос на запуск проверки истечения подписки")
        if (isSubscriptionExpiryCheckingRunning) {
            Log.d(tag, "startSubscriptionExpiryChecking - Проверка истечения подписки уже запущена, пропускаем.")
            return
        }

        isSubscriptionExpiryCheckingRunning = true
        Log.d(tag, "startSubscriptionExpiryChecking - Запуск проверки истечения подписки")

        // Сразу выполняем первую проверку
        checkSubscriptionExpiry()

        mainHandler.postDelayed(object : Runnable {
            override fun run() {
                if (isVpnConnected) {
                    Log.d(tag, "startSubscriptionExpiryChecking - Выполнение проверки истечения подписки")
                    checkSubscriptionExpiry()
                    mainHandler.postDelayed(this, subscriptionCheckInterval)
                } else {
                    Log.d(tag, "startSubscriptionExpiryChecking - VPN отключен, остановка проверки истечения подписки")
                    isSubscriptionExpiryCheckingRunning = false
                }
            }
        }, subscriptionCheckInterval)
    }

    // Новый метод: Остановка проверки истечения срока подписки
    private fun stopSubscriptionExpiryChecking() {
        Log.d(tag, "stopSubscriptionExpiryChecking - Остановка проверки истечения подписки")
        isSubscriptionExpiryCheckingRunning = false
    }

    // Новый метод: Проверка истечения срока подписки
    private fun checkSubscriptionExpiry() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                val expiryDateString = prefs.getString("flutter.expiryDate", null)

                if (expiryDateString == null) {
                    Log.d(tag, "checkSubscriptionExpiry - Дата окончания подписки не найдена. Попытка получить с сервера.")
                    fetchAndSaveExpiryDate()
                    return@launch
                }

                try {
                    // Пробуем распарсить дату в разных форматах, так как она может быть в разных форматах
                    val expiryDate = parseDate(expiryDateString)

                    if (expiryDate != null) {
                        val currentDate = Date()

                        Log.d(tag, "checkSubscriptionExpiry - Текущая дата: $currentDate, Дата окончания: $expiryDate")

                        if (currentDate.after(expiryDate)) {
                            Log.d(tag, "checkSubscriptionExpiry - Срок подписки истек. Отключение VPN.")
                            // Обновляем статус на сервере, если есть интернет
                            try {
                                updateUserStatus("DISCONNECTED")
                            } catch (e: Exception) {
                                Log.e(tag, "checkSubscriptionExpiry - Не удалось обновить статус пользователя: ${e.message}")
                            }

                            // Отключаем VPN
                            V2rayController.StopV2ray(this@UnifiedNotifyService)

                            // Показываем уведомление об истечении подписки
                            updateNotification("Подписка истекла", "VPN отключен из-за истечения срока подписки")
                        } else {
                            // Если дата истечения еще не наступила, обновляем информацию о днях до окончания
                            val daysLeft = calculateDaysLeft(currentDate, expiryDate)
                            Log.d(tag, "checkSubscriptionExpiry - Дней до истечения подписки: $daysLeft")
                        }
                    } else {
                        Log.e(tag, "checkSubscriptionExpiry - Не удалось распарсить дату: $expiryDateString")
                        // Пробуем обновить дату с сервера
                        fetchAndSaveExpiryDate()
                    }
                } catch (e: Exception) {
                    Log.e(tag, "checkSubscriptionExpiry - Ошибка при обработке даты: ${e.message}")
                }
            } catch (e: Exception) {
                Log.e(tag, "checkSubscriptionExpiry - Ошибка при проверке истечения подписки: ${e.message}")
            }
        }
    }

    // Вспомогательный метод для расчета количества дней между датами
    private fun calculateDaysLeft(currentDate: Date, expiryDate: Date): Int {
        val diff = expiryDate.time - currentDate.time
        return (diff / (24 * 60 * 60 * 1000)).toInt()
    }

    // Вспомогательный метод для парсинга даты из разных форматов
    private fun parseDate(dateString: String): Date? {
        val formats = arrayOf(
            "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", // ISO 8601 с миллисекундами
            "yyyy-MM-dd'T'HH:mm:ss'Z'",      // ISO 8601 без миллисекунд
            "yyyy-MM-dd'T'HH:mm:ss",         // ISO 8601 без Z
            "yyyy-MM-dd"                     // Только дата
        )

        for (format in formats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.US)
                return sdf.parse(dateString)
            } catch (e: Exception) {
                // Просто пробуем следующий формат
            }
        }

        return null
    }

    // Новый метод: Получение даты истечения подписки с сервера и сохранение локально
    private suspend fun fetchAndSaveExpiryDate() {
        val userId = getUserIdFromPrefs()

        if (userId == null) {
            Log.d(tag, "fetchAndSaveExpiryDate - ID пользователя не найден")
            return
        }

        try {
            val prefs = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            val userDoc = Firebase.firestore.collection("users").document(userId).get().await()

            if (userDoc.exists()) {
                val userData = userDoc.data
                if (userData != null && userData.containsKey("expiryDate")) {
                    val timestamp = userData["expiryDate"] as? Timestamp

                    if (timestamp != null) {
                        val expiryDate = timestamp.toDate()
                        val expiryDateString = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(expiryDate)

                        // Сохраняем дату истечения в SharedPreferences
                        prefs.edit().putString("flutter.expiryDate", expiryDateString).apply()

                        Log.d(tag, "fetchAndSaveExpiryDate - Дата окончания подписки сохранена: $expiryDateString")

                        // Сразу проверяем, не истекла ли уже подписка
                        val currentDate = Date()
                        if (currentDate.after(expiryDate)) {
                            Log.d(tag, "fetchAndSaveExpiryDate - Срок подписки уже истек. Отключение VPN.")
                            // Обновляем статус и отключаем VPN
                            updateUserStatus("DISCONNECTED")
                            V2rayController.StopV2ray(this@UnifiedNotifyService)
                            updateNotification("Подписка истекла", "VPN отключен из-за истечения срока подписки")
                        }
                    } else {
                        Log.d(tag, "fetchAndSaveExpiryDate - Timestamp в поле expiryDate равен null")
                    }
                } else {
                    Log.d(tag, "fetchAndSaveExpiryDate - Поле expiryDate не найдено в документе пользователя")
                }
            } else {
                Log.d(tag, "fetchAndSaveExpiryDate - Документ пользователя не найден")
            }
        } catch (e: Exception) {
            Log.e(tag, "fetchAndSaveExpiryDate - Ошибка при получении даты окончания подписки: ${e.message}")
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(tag, "onCreate")
        FirebaseApp.initializeApp(this)
        registerReceiver(connectionInfoReceiver, IntentFilter("V2RAY_CONNECTION_INFO"))
        Log.d(tag, "onCreate - Broadcast Receiver зарегистрирован")
        
        // Инициализируем notification builder заранее
        initNotificationBuilder()
        
        // Предотвращаем "засыпание" сервиса
        acquireWakeLock()
    }

    private fun getNotificationChannelId(): String {
        // Используем тот же ID канала, что и V2rayCoreManager
        return V2rayCoreManager.getInstance().getNotificationChannelId()
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun createNotificationChannel() {
        val channelId = getNotificationChannelId()
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = notificationManager.getNotificationChannel(channelId)

        // Если канал уже существует - обновляем его настройки с более высокой важностью
        if (channel != null) {
            channel.importance = NotificationManager.IMPORTANCE_HIGH // Увеличиваем важность
            channel.enableVibration(false) // Отключаем вибрацию
            channel.vibrationPattern = null
            notificationManager.createNotificationChannel(channel)
        } else {
            // Если канал еще не существует - создаем новый с нужными настройками
            val newChannel = NotificationChannel(
                channelId,
                "VPN Status",
                NotificationManager.IMPORTANCE_HIGH // Используем HIGH важность для более заметных уведомлений
            )
            newChannel.enableVibration(false) // Отключаем вибрацию
            newChannel.vibrationPattern = null
            newChannel.setSound(null, null) // Отключаем звук
            notificationManager.createNotificationChannel(newChannel)
        }
    }

    private fun startForegroundServiceWithNotification() {
        val channelId = getNotificationChannelId()

        // Создаем/обновляем канал уведомлений с отключенной вибрацией
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel()
        }

        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // Создаем интент для остановки VPN (как в V2rayCoreManager)
        val stopIntent: Intent
        if (AppConfigs.V2RAY_CONNECTION_MODE == AppConfigs.V2RAY_CONNECTION_MODES.PROXY_ONLY) {
            stopIntent = Intent(this, V2rayProxyOnlyService::class.java)
        } else {
            // По умолчанию используем VPN_TUN режим
            stopIntent = Intent(this, V2rayVPNService::class.java)
        }
        stopIntent.putExtra("COMMAND", AppConfigs.V2RAY_SERVICE_COMMANDS.STOP_SERVICE)

        // Получаем PendingIntent для сервиса (не для broadcast)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val disconnectPendingIntent = PendingIntent.getService(
            this, 0, stopIntent, flags
        )

        notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setContentTitle("VPN Подключение...")
            .setContentText("Установление защищенного соединения")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH) // Повышаем приоритет для приоритета над другими уведомлениями
            .setVibrate(null) // Явно отключаем вибрацию
            .setOngoing(true)
            .setOnlyAlertOnce(true) // Важно! Только одно оповещение при первом показе
            .addAction(R.mipmap.ic_launcher, "Отключить VPN", disconnectPendingIntent)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                Log.e(tag, "Разрешение на уведомления не предоставлено")
                return
            }
        }
        val notification = notificationBuilder.build()
        startForeground(notificationId, notification)
        Log.d(tag, "startForegroundServiceWithNotification - Foreground service запущен с информативным уведомлением")
    }

    private fun updateNotification(title: String, text: String) {
        try {
            // Проверка на null и повторная инициализация, если необходимо
            if (::notificationBuilder.isInitialized.not()) {
                Log.d(tag, "updateNotification - NotificationBuilder не инициализирован, выполняем инициализацию")
                initNotificationBuilder()
            }
            
            Log.d(tag, "updateNotification - Обновляем уведомление: $title | $text")
            
            notificationBuilder.setContentTitle(title)
            notificationBuilder.setContentText(text)
            notificationBuilder.setVibrate(null)
            notificationBuilder.setOnlyAlertOnce(true)
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    Log.e(tag, "Разрешение на уведомления не предоставлено для обновления")
                    return
                }
            }
            
            // Проверяем, находится ли сервис в режиме переднего плана
            // и если да, то устанавливаем уведомление через startForeground
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Log.d(tag, "updateNotification - Обновление через startForeground")
                    startForeground(notificationId, notificationBuilder.build())
                } else {
                    Log.d(tag, "updateNotification - Обновление через NotificationManager")
                    val notificationManager = NotificationManagerCompat.from(this)
                    notificationManager.notify(notificationId, notificationBuilder.build())
                }
            } catch (e: Exception) {
                Log.e(tag, "updateNotification - Ошибка при обновлении через foreground: ${e.message}")
                // Запасной вариант: используем NotificationManager
                val notificationManager = NotificationManagerCompat.from(this)
                notificationManager.notify(notificationId, notificationBuilder.build())
            }
        } catch (e: Exception) {
            Log.e(tag, "updateNotification - Ошибка обновления уведомления: ${e.message}", e)
            // Попытка восстановления уведомления
            try {
                Log.d(tag, "updateNotification - Попытка восстановления уведомления")
                initNotificationBuilder()
                startForegroundServiceWithNotification()
            } catch (e2: Exception) {
                Log.e(tag, "updateNotification - Не удалось восстановить уведомление: ${e2.message}", e2)
            }
        }
    }

    private fun stopForegroundServiceSafely() {
        Log.d(tag, "stopForegroundServiceSafely - Останавливаем foreground service")
        stopForeground(true)
    }

    private fun startTrafficUpdates() {
        Log.d(tag, "startTrafficUpdates - Запрос на запуск обновления трафика")
        if (isTrafficUpdatesRunning) {
            Log.d(tag, "startTrafficUpdates - Обновление трафика уже запущено, пропускаем.")
            return
        }

        val isProUser = getProStatus()
        if (!isProUser) {
            Log.d(tag, "startTrafficUpdates - Аккаунт не Pro, обновление трафика не запускается.")
            return
        }

        isTrafficUpdatesRunning = true
        Log.d(tag, "startTrafficUpdates - Запуск обновления трафика для Pro пользователя")
        mainHandler.postDelayed(object : Runnable {
            override fun run() {
                if (isVpnConnected) {
                    Log.d(tag, "startTrafficUpdates - Выполнение обновления трафика")
                    CoroutineScope(Dispatchers.IO).launch {
                        sendTrafficDataToFirebase()
                    }
                    mainHandler.postDelayed(this, trafficUpdateInterval)
                } else {
                    Log.d(tag, "startTrafficUpdates - VPN отключен, остановка обновлений трафика")
                    isTrafficUpdatesRunning = false
                }
            }
        }, trafficUpdateInterval)
    }

    private suspend fun sendTrafficDataToFirebase() {
        Log.d(tag, "sendTrafficDataToFirebase - Вход в функцию")

        val isProUser = getProStatus()
        if (!isProUser) {
            Log.d(tag, "sendTrafficDataToFirebase - Аккаунт не Pro, отправка данных трафика отменена.")
            return
        }

        val userId = getUserIdFromPrefs()
        val serverName = getServerNameFromPrefs()

        userId?.let { userId ->
            val serverNameValue = serverName ?: "UnknownServer"
            Log.d(tag, "sendTrafficDataToFirebase - User ID: $userId, Server Name: $serverNameValue")
            val timestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)

            val deltaUploadBytes = max(0, lastUploadBytes - previousUploadBytes)
            val deltaDownloadBytes = max(0, lastDownloadBytes - previousDownloadBytes)

            val deltaUploadMB = deltaUploadBytes.toDouble() / (1024 * 1024)
            val deltaDownloadMB = deltaDownloadBytes.toDouble() / (1024 * 1024)

            val formattedDeltaUploadMB = String.format(Locale.US, "%.2f", deltaUploadMB)
            val formattedDeltaDownloadMB = String.format(Locale.US, "%.2f", deltaDownloadMB)

            val newData = "$timestamp|$formattedDeltaUploadMB|$formattedDeltaDownloadMB|$serverNameValue"

            Log.d(tag, "sendTrafficDataToFirebase - Отправка данных: $newData")
            try {
                Firebase.firestore.collection("users")
                    .document(userId)
                    .update("data", FieldValue.arrayUnion(newData))
                Log.d(tag, "sendTrafficDataToFirebase - Данные трафика успешно отправлены: $newData")

                previousUploadBytes = lastUploadBytes
                previousDownloadBytes = lastDownloadBytes

            } catch (e: Exception) {
                Log.e(tag, "sendTrafficDataToFirebase - Ошибка при отправке данных трафика: ${e.message}")
            }
        } ?: run {
            Log.w(tag, "sendTrafficDataToFirebase - User ID не найден, невозможно отправить данные трафика.")
        }
    }

    private fun updateTrafficData(currentUploadBytes: Long, currentDownloadBytes: Long) {
        this.lastUploadBytes = currentUploadBytes
        this.lastDownloadBytes = currentDownloadBytes
    }

    private fun stopTrafficUpdates() {
        Log.d(tag, "stopTrafficUpdates - Остановка обновлений трафика")
        mainHandler.removeCallbacksAndMessages(null)
        isTrafficUpdatesRunning = false
    }

    private fun startAccountChecking() {
        Log.d(tag, "startAccountChecking - Запрос на запуск проверки аккаунта")
        if (isAccountCheckingRunning) {
            Log.d(tag, "startAccountChecking - Проверка аккаунта уже запущена, пропускаем.")
            return
        }

        isAccountCheckingRunning = true
        Log.d(tag, "startAccountChecking - Запуск проверки аккаунта")
        mainHandler.postDelayed(object : Runnable {
            override fun run() {
                if (isVpnConnected) {
                    Log.d(tag, "startAccountChecking - Выполнение проверки аккаунта")
                    performAccountCheck()
                    mainHandler.postDelayed(this, accountCheckInterval)
                } else {
                    Log.d(tag, "startAccountChecking - VPN отключен, остановка проверки аккаунта")
                    isAccountCheckingRunning = false
                }
            }
        }, accountCheckInterval)
    }

    private fun stopAccountChecking() {
        Log.d(tag, "stopAccountChecking - Остановка проверки аккаунта")
        mainHandler.removeCallbacksAndMessages(null)
        isAccountCheckingRunning = false
    }

    private fun performAccountCheck() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val userId = getUserIdFromPrefs()

                if (userId != null) {
                    Log.d(tag, "performAccountCheck - Найден User ID: $userId")
                    val userProfile = fetchUserProfile(userId)

                    if (userProfile != null && userProfile["type"] != null) {
                        val userType = userProfile["type"] as String
                        val isPro = userType == "Pro"
                        val wasPro = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE).getBoolean("flutter.isPro", false)

                        Log.d(tag, "performAccountCheck - Тип пользователя: $userType, был Pro: $wasPro, текущий Pro: $isPro")

                        if (wasPro && !isPro) {
                            Log.d(tag, "performAccountCheck - Пользователь больше не Pro. Останавливаем V2Ray.")
                            V2rayController.StopV2ray(this@UnifiedNotifyService)
                            updateUserStatus("DISCONNECTED")
                        } else if (isPro) {
                            Log.d(tag, "performAccountCheck - Пользователь имеет статус Pro.")
                        } else {
                            Log.d(tag, "performAccountCheck - Пользователь не Pro и статус не изменился.")
                        }
                    } else {
                        Log.d(tag, "performAccountCheck - Профиль пользователя не найден или тип не определен. Обновляем статус на DISCONNECTED.")
                        updateUserStatus("DISCONNECTED")
                    }
                } else {
                    Log.d(tag, "performAccountCheck - Токен пользователя не найден.")
                }
            } catch (e: Exception) {
                Log.e(tag, "performAccountCheck - Ошибка при проверке аккаунта: ${e.message}")
            }
        }
    }

    private suspend fun fetchUserProfile(userId: String): Map<String, Any>? {
        return try {
            Log.d(tag, "fetchUserProfile - Получение профиля пользователя с ID: $userId")
            val snapshot = Firebase.firestore.collection("users").document(userId).get().await()
            if (snapshot.exists()) {
                snapshot.data
            } else {
                Log.d(tag, "fetchUserProfile - Профиль пользователя не найден.")
                null
            }
        } catch (e: Exception) {
            Log.e(tag, "fetchUserProfile - Ошибка при получении профиля пользователя: ${e.message}")
            null
        }
    }

    private fun updateUserStatus(status: String) {
        Log.d("AccountCheckService", "updateUserStatus called with status: $status")

        val userId = getUserIdFromPrefs()

        userId?.let {
            Log.d("AccountCheckService", "userId is not null, proceeding with update. userId: $it")
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val newStatus = if (status == "CONNECTED") "active" else "inactive"
                    Log.d("AccountCheckService", "Updating user status to: $newStatus for userId: $it")
                    Firebase.firestore.collection("users").document(it).update("status", newStatus).await()
                    Log.d("AccountCheckService", "Successfully updated user status to: $newStatus for userId: $it")
                } catch (e: Exception) {
                    Log.e("AccountCheckService", "Error updating user status for userId: $it. Error: ${e.message}")
                }
            }
        } ?: run {
            Log.d("AccountCheckService", "userId is null, skipping updateStatus.")
        }
    }

    private fun getUserIdFromPrefs(): String? {
        return getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            .getString("flutter.token", null)
    }

    private fun getServerNameFromPrefs(): String? {
        return getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            .getString("flutter.serverName", null)
    }

    private fun getProStatus(): Boolean {
        return getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
            .getBoolean("flutter.isPro", false)
    }

    private fun initNotificationBuilder() {
        val channelId = getNotificationChannelId()
        
        // Создаем канал уведомлений, если он еще не создан
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel()
        }
        
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        
        // Создаем интент для остановки VPN
        val stopIntent: Intent = if (AppConfigs.V2RAY_CONNECTION_MODE == AppConfigs.V2RAY_CONNECTION_MODES.PROXY_ONLY) {
            Intent(this, V2rayProxyOnlyService::class.java)
        } else {
            Intent(this, V2rayVPNService::class.java)
        }
        stopIntent.putExtra("COMMAND", AppConfigs.V2RAY_SERVICE_COMMANDS.STOP_SERVICE)
        
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        
        val disconnectPendingIntent = PendingIntent.getService(this, 0, stopIntent, flags)
        
        notificationBuilder = NotificationCompat.Builder(this, channelId)
            .setContentTitle("VPN Подключение...")
            .setContentText("Установление защищенного соединения")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVibrate(null)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(R.mipmap.ic_launcher, "Отключить VPN", disconnectPendingIntent)
        
        Log.d(tag, "initNotificationBuilder - NotificationBuilder инициализирован")
    }

    private fun acquireWakeLock() {
        if (wakeLock == null) {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "MRX:VPNServiceWakeLock"
            )
            // Увеличиваем время WakeLock до бесконечности
            wakeLock?.acquire(0L) // Удерживаем бесконечно, будет освобожден в onDestroy
            Log.d(tag, "WakeLock приобретен для поддержания сервиса в активном состоянии (бессрочный)")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(tag, "onStartCommand вызван, flags: $flags, startId: $startId")
        
        // Получаем параметр перезапуска из MainActivity
        val restartFromActivity = intent?.getBooleanExtra("RESTART_FROM_ACTIVITY", false) ?: false
        
        if (restartFromActivity) {
            Log.d(tag, "Перезапуск из MainActivity - проверяем состояние VPN")
        }
        
        // Проверяем, работал ли сервис до перезапуска или это перезапуск из MainActivity
        if (flags and START_FLAG_REDELIVERY != 0 || flags and START_FLAG_RETRY != 0 || restartFromActivity) {
            Log.d(tag, "Сервис перезапущен. Проверяем состояние V2Ray...")
            
            // Проверяем, работает ли V2Ray core
            val v2rayManager = V2rayCoreManager.getInstance()
            if (v2rayManager.isV2rayCoreRunning()) {
                Log.d(tag, "V2Ray core работает. Восстанавливаем уведомление...")
                isVpnConnected = true
                
                // Инициализируем билдер, если необходимо
                if (::notificationBuilder.isInitialized.not()) {
                    Log.d(tag, "Инициализация notificationBuilder")
                    initNotificationBuilder()
                }
                
                // Запускаем как foreground service с уведомлением
                try {
                    Log.d(tag, "Вызов startForegroundServiceWithNotification")
                    startForegroundServiceWithNotification()
                    
                    // Обновляем уведомление с информацией о трафике
                    updateNotificationWithTraffic()
                    
                    // Перезапускаем периодические задачи
                    startPeriodicTasks()
                } catch (e: Exception) {
                    Log.e(tag, "Ошибка при отображении уведомления: ${e.message}", e)
                }
            } else {
                Log.d(tag, "V2Ray core не работает, уведомление не требуется")
                isVpnConnected = false
            }
        }
        
        // Всегда инициализируем notification builder
        if (::notificationBuilder.isInitialized.not()) {
            initNotificationBuilder()
        }
        
        // Убеждаемся, что WakeLock активен
        acquireWakeLock()
        
        // Если что-то случится с сервисом - система попытается перезапустить его
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(tag, "onDestroy")
        
        try {
            unregisterReceiver(connectionInfoReceiver)
            Log.d(tag, "onDestroy - Broadcast Receiver отписан")
        } catch (e: Exception) {
            Log.e(tag, "onDestroy - Ошибка при отписке от Broadcast Receiver: ${e.message}")
        }
        
        stopPeriodicTasks()
        coroutineScope.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        
        // Освобождаем WakeLock
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
            Log.d(tag, "WakeLock освобожден")
        }
        
        // Перезапустим себя, если V2Ray всё ещё работает
        try {
            val v2rayManager = V2rayCoreManager.getInstance()
            if (v2rayManager.isV2rayCoreRunning()) {
                Log.d(tag, "onDestroy - V2Ray все еще работает, запрос на перезапуск сервиса уведомлений")
                val intent = Intent(this, UnifiedNotifyService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(intent)
                } else {
                    startService(intent)
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "onDestroy - Ошибка при проверке состояния V2Ray: ${e.message}")
        }
        
        Log.d(tag, "onDestroy - Все задачи остановлены и Coroutine scope отменен")
    }

    override fun onBind(intent: Intent?): IBinder? {
        Log.d(tag, "onBind")
        return null
    }
}