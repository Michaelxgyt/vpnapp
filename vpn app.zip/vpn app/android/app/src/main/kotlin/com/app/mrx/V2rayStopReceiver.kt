package com.app.mrx

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.github.blueboytm.flutter_v2ray.v2ray.V2rayController

class V2rayStopReceiver : BroadcastReceiver() {
    private val tag = "V2rayStopReceiver"

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context != null) {
            Log.d(tag, "onReceive - Получен запрос на остановку V2Ray из уведомления")
            V2rayController.StopV2ray(context)
            // Опционально: Можно также остановить UnifiedNotifyService здесь, если необходимо
            // context.stopService(Intent(context, UnifiedNotifyService::class.java))
        } else {
            Log.w(tag, "onReceive - Context равен null, не могу остановить V2Ray")
        }
    }
}