package com.app.mrx

import android.app.Application
import com.github.blueboytm.flutter_v2ray.v2ray.core.V2rayCoreManager

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Инициализация V2rayCoreManager
        val v2rayManager = V2rayCoreManager.getInstance()
    }
}
